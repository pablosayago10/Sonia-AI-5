plugins {
    id("com.android.application") version "8.6.1" apply false
    // La librería de IA (litertlm-android) y sus piezas internas vienen compiladas con
    // Kotlin 2.4.0; con Kotlin 2.0.21 el compilador no podía ni leerlas. Subimos a la
    // versión estable más reciente (2.4.21) para que las entienda.
    id("org.jetbrains.kotlin.android") version "2.4.21" apply false
}
