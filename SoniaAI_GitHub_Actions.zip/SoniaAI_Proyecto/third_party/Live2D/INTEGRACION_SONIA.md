# Live2D Native 5-r.5 en Sonia AI

Se incluye el SDK Native 5-r.5 y el ejemplo Android/OpenGL mínimo como referencia de integración.

## Rutas incluidas
- `Core/include`
- `Core/lib/android/arm64-v8a/libLive2DCubismCore.a`
- `Framework`
- `Samples/Common`
- `Samples/OpenGL/thirdParty/stb`
- `Samples/OpenGL/AndroidMinimum/cpp`
- `Samples/OpenGL/AndroidMinimum/java` (si está disponible en el paquete fuente)

## Próxima tarea de ingeniería
Crear el target CMake `sonia_live2d`, enlazar `Framework`, `Live2DCubismCore`, `GLESv2` y `log`, y adaptar el puente JNI del ejemplo oficial a la vista GL de Sonia. La muestra oficial debe mantenerse como referencia de licencia y arquitectura; no copiar clases a ciegas sin adaptar nombres JNI.

El modelo de Sonia se encuentra en `app/src/main/assets/live2d/xl.model3.json` y la textura reducida en `xl.4096/texture_00.png`.
