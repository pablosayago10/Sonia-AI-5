package com.sonia.ai

import android.os.Handler
import android.os.Looper

/** Emociones de la cara de Sonia. El orden (ordinal) debe coincidir con kEmotions en LAppModel.cpp. */
enum class AvatarEmotion(val label: String, val emoji: String) {
    NEUTRAL("neutral", "😐"),
    HAPPY("feliz", "😊"),
    ANGRY("enojada", "😠"),
    SAD("triste", "😢"),
    SURPRISED("sorprendida", "😮"),
    PENSIVE("pensativa", "🤔"),
    SHY("tímida", "😳"),
    WINK("guiño", "😉"),
    SLEEPY("cansada", "😴"),
    LAUGH("risa", "😂"),
    SMUG("presumida", "😏"),
    BORED("aburrida", "😒")
}

/** Movimientos del cuerpo. El orden (ordinal) debe coincidir con LAppModel.cpp (ApplyEmotion). */
enum class AvatarActivity { NONE, LOOK_AROUND, STRETCH, YAWN, DANCE, LISTEN, SLEEP, WORK, NOD, SHAKE }

/**
 * Maneja la expresión de la cara. Hay dos modos:
 *  - Automático: Sonia reacciona según lo que dice (palabras y emojis de su respuesta) y
 *    después de unos segundos vuelve a la cara neutral.
 *  - Manual: el usuario elige una expresión (menú o "poné cara de enojada") y se queda así
 *    hasta que elija otra o vuelva a "Automático".
 */
object EmotionController {

    private val main = Handler(Looper.getMainLooper())
    private var manual = false
    private val reset = Runnable { apply(AvatarEmotion.NEUTRAL) }

    val isManual: Boolean get() = manual

    private fun apply(e: AvatarEmotion) {
        try { Live2DJniBridge.nativeSetEmotion(e.ordinal) } catch (_: Throwable) {}
    }

    /** El usuario pide una expresión. Se mantiene hasta que pida otra. */
    fun setManual(e: AvatarEmotion) {
        main.removeCallbacks(reset)
        manual = e != AvatarEmotion.NEUTRAL
        apply(e)
    }

    /** Vuelve al modo automático (cara neutral que reacciona sola). */
    fun setAuto() {
        main.removeCallbacks(reset)
        manual = false
        apply(AvatarEmotion.NEUTRAL)
    }

    /** Sonia reacciona al texto que acaba de decir. No hace nada si hay una expresión manual. */
    fun react(text: String, holdMs: Long = 7000) {
        val e = detect(text) ?: return
        flash(e, holdMs)
    }

    /** Pone una expresión un rato y vuelve a neutral. No pisa una expresión elegida a mano. */
    fun flash(e: AvatarEmotion, holdMs: Long) {
        if (manual) return
        main.removeCallbacks(reset)
        apply(e)
        main.postDelayed(reset, holdMs.coerceIn(1500, 20000))
    }

    fun detect(text: String): AvatarEmotion? {
        val raw = text
        when {
            raw.contains("😉") -> return AvatarEmotion.WINK
            raw.contains("😴") || raw.contains("🥱") -> return AvatarEmotion.SLEEPY
            raw.contains("😂") || raw.contains("🤣") -> return AvatarEmotion.LAUGH
            raw.contains("😏") -> return AvatarEmotion.SMUG
            raw.contains("😒") || raw.contains("🙄") -> return AvatarEmotion.BORED
            raw.contains("😠") || raw.contains("😡") || raw.contains("🤬") -> return AvatarEmotion.ANGRY
            raw.contains("😢") || raw.contains("😭") || raw.contains("😞") || raw.contains("😔") -> return AvatarEmotion.SAD
            raw.contains("😮") || raw.contains("😲") || raw.contains("😯") -> return AvatarEmotion.SURPRISED
            raw.contains("🤔") -> return AvatarEmotion.PENSIVE
            raw.contains("😳") || raw.contains("☺") || raw.contains("🥰") -> return AvatarEmotion.SHY
            raw.contains("😊") || raw.contains("😄") || raw.contains("😁") || raw.contains("😃") ||
                raw.contains("😀") || raw.contains("🎉") || raw.contains("🎵") -> return AvatarEmotion.HAPPY
        }
        val n = " " + MusicController.normalize(text) + " "
        fun any(vararg w: String) = w.any { n.contains(it) }
        return when {
            any(" jajaja", " jajajaja", " me mori de risa") -> AvatarEmotion.LAUGH
            any(" tengo sueno", " cansad", " bostez") -> AvatarEmotion.SLEEPY
            any(" aburrid") -> AvatarEmotion.BORED
            any(" enojad", " furios", " bronca", " me molesta", " que fastidio") -> AvatarEmotion.ANGRY
            any(" triste", " lamento", " lo siento", " que pena", " perdon") -> AvatarEmotion.SAD
            any(" wow", " increible", " sorpresa", " sorprendid", " no lo puedo creer") -> AvatarEmotion.SURPRISED
            any(" hmm", " quizas", " tal vez", " no estoy segura", " depende", " dejame pensar") -> AvatarEmotion.PENSIVE
            any(" verguenza", " me da pena", " que lindo", " me hace feliz", " me sonroj") -> AvatarEmotion.SHY
            any(" jaja", " jeje", " genial", " feliz", " alegr", " excelente", " divertid", " buenisimo",
                " me encanta", " que bueno", " listo") -> AvatarEmotion.HAPPY
            else -> null
        }
    }

    /** Palabra suelta -> emoción ("enojada", "feliz"...). null si no es una. */
    fun fromWord(w: String): AvatarEmotion? = when (w) {
        "feliz", "contenta", "alegre", "sonriente", "content", "sonriendo", "risuena" -> AvatarEmotion.HAPPY
        "enojada", "enojo", "furiosa", "brava", "molesta", "enojarte", "enojate", "enfadada" -> AvatarEmotion.ANGRY
        "triste", "tristeza", "llorando", "llorar", "deprimida" -> AvatarEmotion.SAD
        "sorprendida", "sorpresa", "asombrada", "sorprenderte" -> AvatarEmotion.SURPRISED
        "pensativa", "pensando", "pensar", "reflexiva", "dudando", "intrigada" -> AvatarEmotion.PENSIVE
        "timida", "avergonzada", "verguenza", "sonrojada", "apenada" -> AvatarEmotion.SHY
        "guino", "guinar", "guinando", "picara", "coqueta" -> AvatarEmotion.WINK
        "cansada", "dormida", "sueno", "somnolienta", "agotada" -> AvatarEmotion.SLEEPY
        "risa", "riendo", "carcajada", "reir", "riete", "carcajeando" -> AvatarEmotion.LAUGH
        "presumida", "canchera", "engreida", "orgullosa", "picona", "arrogante" -> AvatarEmotion.SMUG
        "aburrida", "aburrimiento", "fastidiada" -> AvatarEmotion.BORED
        "neutral", "normal", "seria", "serena", "tranquila" -> AvatarEmotion.NEUTRAL
        else -> null
    }
}


/**
 * Movimientos del cuerpo de Sonia: los que dependen de lo que está haciendo (escuchar, trabajar,
 * bailar con la música, dormir) y los gestos sueltos (mirar alrededor, estirarse, bostezar...).
 * Se llama siempre desde el hilo principal.
 */
object ActivityController {
    private val main = Handler(Looper.getMainLooper())
    private var oneShot = AvatarActivity.NONE
    private val endShot = Runnable { oneShot = AvatarActivity.NONE; refresh() }

    var listening = false
        set(v) { field = v; refresh() }
    var working = false
        set(v) { field = v; refresh() }
    var dancing = false
        set(v) { field = v; refresh() }
    var sleeping = false
        set(v) { field = v; refresh() }

    val isBusy: Boolean get() = listening || working || dancing

    fun oneShot(a: AvatarActivity, durMs: Long) {
        oneShot = a
        main.removeCallbacks(endShot)
        main.postDelayed(endShot, durMs)
        refresh()
    }

    private fun refresh() {
        val a = when {
            oneShot != AvatarActivity.NONE -> oneShot
            listening -> AvatarActivity.LISTEN
            working -> AvatarActivity.WORK
            dancing -> AvatarActivity.DANCE
            sleeping -> AvatarActivity.SLEEP
            else -> AvatarActivity.NONE
        }
        try { Live2DJniBridge.nativeSetActivity(a.ordinal) } catch (_: Throwable) {}
    }
}

/**
 * Animaciones de "reposo": si nadie le habla por un rato, Sonia mira alrededor, bosteza, se
 * estira, se aburre o tararea; y si pasa mucho tiempo, se duerme. Cualquier interacción la despierta.
 */
object IdleDirector {
    private val main = Handler(Looper.getMainLooper())
    private val rnd = java.util.Random()
    private var started = false
    private var lastActive = android.os.SystemClock.elapsedRealtime()
    private var nextAction = lastActive + 25000
    private val tick = object : Runnable {
        override fun run() {
            step()
            main.postDelayed(this, 4000)
        }
    }

    fun start() {
        if (started) return
        started = true
        main.postDelayed(tick, 4000)
    }

    /** Avisar cada vez que el usuario hace algo (escribe, habla, abre la app). */
    fun touch() {
        val now = android.os.SystemClock.elapsedRealtime()
        lastActive = now
        nextAction = now + 25000 + rnd.nextInt(15000)
        if (ActivityController.sleeping) {
            ActivityController.sleeping = false
            EmotionController.flash(AvatarEmotion.SURPRISED, 1500)
        }
    }

    private fun step() {
        val now = android.os.SystemClock.elapsedRealtime()
        if (ActivityController.isBusy) {
            lastActive = now
            return
        }
        val idle = now - lastActive
        if (idle > 180000) {
            ActivityController.sleeping = true
            return
        }
        if (idle > 20000 && now >= nextAction && !ActivityController.sleeping) {
            nextAction = now + 20000 + rnd.nextInt(30000)
            when (rnd.nextInt(6)) {
                0, 1 -> ActivityController.oneShot(AvatarActivity.LOOK_AROUND, 6000)
                2 -> {
                    ActivityController.oneShot(AvatarActivity.YAWN, 3500)
                    EmotionController.flash(AvatarEmotion.SLEEPY, 4000)
                }
                3 -> ActivityController.oneShot(AvatarActivity.STRETCH, 4000)
                4 -> EmotionController.flash(AvatarEmotion.BORED, 7000)
                else -> {
                    EmotionController.flash(AvatarEmotion.HAPPY, 6000)
                    ActivityController.oneShot(AvatarActivity.DANCE, 5000)
                }
            }
        }
    }
}
