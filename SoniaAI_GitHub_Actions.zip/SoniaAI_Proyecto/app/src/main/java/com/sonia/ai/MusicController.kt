package com.sonia.ai

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import java.text.Normalizer
import java.util.Locale
import kotlin.random.Random

/**
 * Reproductor de música compartido por la app y por la burbuja flotante.
 *
 * La "biblioteca" son las canciones de la carpeta elegida en Ajustes (o, si se eligieron
 * archivos sueltos, esos archivos). Se puede pedir una canción por nombre ("poné Soda
 * Stereo"), una al azar, pausar, seguir, pasar, etc. Siempre se usa desde el hilo principal.
 */
object MusicController {

    class Track(val uri: Uri, val title: String, val searchText: String)

    private const val PREFS = "sonia_prefs"
    private const val KEY_TREE = "music_tree_uri"
    private const val MAX_TRACKS = 4000
    private const val MAX_DEPTH = 8

    private val main = Handler(Looper.getMainLooper())
    private var appContext: Context? = null
    private var player: MediaPlayer? = null
    private val tracks = ArrayList<Track>()
    private var index = 0
    private var shuffle = false
    private var paused = false
    @Volatile private var scanning = false

    /** Aviso de eventos que pasan solos (pasó a la siguiente, hubo un error...). */
    var onEvent: ((String) -> Unit)? = null

    val trackCount: Int get() = tracks.size
    val hasLibrary: Boolean get() = tracks.isNotEmpty()
    val isPlaying: Boolean get() = try { player?.isPlaying == true } catch (_: Exception) { false }
    val hasPlayer: Boolean get() = player != null
    val isScanning: Boolean get() = scanning

    fun init(context: Context) {
        if (appContext == null) appContext = context.applicationContext
    }

    fun savedFolderUri(context: Context): Uri? =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_TREE, null)?.let { Uri.parse(it) }

    // ------------------------------------------------------------------ biblioteca

    /** Archivos sueltos elegidos con el selector. Reemplazan a la biblioteca actual. */
    fun setPicked(context: Context, uris: List<Uri>) {
        init(context)
        val list = uris.map { uri ->
            val name = displayName(context, uri) ?: "audio"
            makeTrack(uri, name, "")
        }
        tracks.clear()
        tracks.addAll(list)
        index = 0
        shuffle = false
    }

    /** Guarda la carpeta y la recorre en segundo plano. [onDone] se llama en el hilo principal. */
    fun loadFolder(context: Context, treeUri: Uri, onDone: (Int) -> Unit) {
        init(context)
        val ctx = context.applicationContext
        try {
            ctx.contentResolver.takePersistableUriPermission(
                treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_TREE, treeUri.toString()).apply()
        scan(ctx, treeUri, onDone)
    }

    /** Al abrir la app: si ya había una carpeta guardada y todavía no se cargó, se vuelve a leer. */
    fun restoreFolder(context: Context, onDone: ((Int) -> Unit)? = null) {
        init(context)
        if (tracks.isNotEmpty() || scanning) return
        val uri = savedFolderUri(context) ?: return
        scan(context.applicationContext, uri) { n -> onDone?.invoke(n) }
    }

    fun clearFolder(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(KEY_TREE).apply()
        stop()
        tracks.clear()
    }

    private fun scan(ctx: Context, treeUri: Uri, onDone: (Int) -> Unit) {
        scanning = true
        Thread {
            val found = ArrayList<Track>()
            try {
                val rootId = DocumentsContract.getTreeDocumentId(treeUri)
                walk(ctx, treeUri, rootId, "", 0, found)
            } catch (_: Exception) {
            }
            found.sortBy { it.searchText }
            main.post {
                tracks.clear()
                tracks.addAll(found)
                index = 0
                shuffle = false
                scanning = false
                onDone(found.size)
            }
        }.start()
    }

    private fun walk(
        ctx: Context, tree: Uri, docId: String, path: String, depth: Int, out: ArrayList<Track>
    ) {
        if (depth > MAX_DEPTH || out.size >= MAX_TRACKS) return
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        val cursor = try {
            ctx.contentResolver.query(children, cols, null, null, null)
        } catch (_: Exception) {
            null
        } ?: return
        cursor.use {
            while (it.moveToNext()) {
                if (out.size >= MAX_TRACKS) return
                val id = it.getString(0) ?: continue
                val name = it.getString(1) ?: continue
                val mime = it.getString(2) ?: ""
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    walk(ctx, tree, id, "$path$name ", depth + 1, out)
                } else if (isAudio(name, mime)) {
                    out.add(makeTrack(DocumentsContract.buildDocumentUriUsingTree(tree, id), name, path))
                }
            }
        }
    }

    private fun isAudio(name: String, mime: String): Boolean {
        if (mime.startsWith("audio/")) return true
        val n = name.lowercase(Locale.ROOT)
        return listOf(".mp3", ".m4a", ".aac", ".wav", ".ogg", ".opus", ".flac", ".amr", ".mid")
            .any { n.endsWith(it) }
    }

    private fun makeTrack(uri: Uri, fileName: String, folderPath: String): Track {
        val title = fileName.substringBeforeLast('.', fileName)
        return Track(uri, title, normalize("$folderPath$title"))
    }

    private fun displayName(ctx: Context, uri: Uri): String? = try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (_: Exception) {
        null
    }

    // ------------------------------------------------------------------ reproducción
    // Todas devuelven el texto que Sonia le dice al usuario.

    fun playAny(randomOrder: Boolean): String {
        if (tracks.isEmpty()) return noLibraryMessage()
        shuffle = randomOrder
        index = if (randomOrder) Random.nextInt(tracks.size) else index.coerceIn(0, tracks.size - 1)
        return playCurrent()
    }

    /** Busca por nombre (con tolerancia a palabras sueltas) y reproduce la mejor coincidencia. */
    fun playQuery(query: String): String {
        if (tracks.isEmpty()) return noLibraryMessage()
        val best = findBest(query)
            ?: return "No encontré nada parecido a «$query» en tu música. Probá con otra parte del nombre o del artista."
        shuffle = false
        index = best
        return playCurrent()
    }

    fun findBest(query: String): Int? {
        val words = normalize(query).split(' ').filter { it.length >= 2 && it !in STOP }
        if (words.isEmpty()) return null
        var bestIdx = -1
        var bestScore = 0.0
        for ((i, t) in tracks.withIndex()) {
            val hits = words.count { w -> t.searchText.contains(w) }
            if (hits == 0) continue
            // Más palabras acertadas = mejor; ante empate, el nombre más corto (más exacto).
            val score = hits.toDouble() / words.size - t.searchText.length / 100000.0
            if (score > bestScore) {
                bestScore = score
                bestIdx = i
            }
        }
        return if (bestIdx >= 0 && bestScore >= 0.5) bestIdx else null
    }

    private fun playCurrent(): String {
        val ctx = appContext ?: return "No pude iniciar el reproductor."
        if (tracks.isEmpty()) return noLibraryMessage()
        val track = tracks[index]
        return try {
            releasePlayer()
            paused = false
            player = MediaPlayer().apply {
                setDataSource(ctx, track.uri)
                setOnPreparedListener { it.start(); ActivityController.dancing = true }
                setOnCompletionListener {
                    if (tracks.size > 1) {
                        index = if (shuffle) Random.nextInt(tracks.size) else (index + 1) % tracks.size
                        val msg = playCurrent()
                        onEvent?.invoke(msg)
                    } else {
                        ActivityController.dancing = false
                        onEvent?.invoke("Terminó la canción.")
                    }
                }
                setOnErrorListener { _, _, _ ->
                    ActivityController.dancing = false
                    onEvent?.invoke("No pude reproducir «${track.title}».")
                    true
                }
                prepareAsync()
            }
            "Reproduciendo «${track.title}». 🎵"
        } catch (e: Exception) {
            "No pude abrir «${track.title}»."
        }
    }

    fun pause(): String {
        val p = player
        return if (p != null && isPlaying) {
            p.pause()
            paused = true
            ActivityController.dancing = false
            "Pausé la música. 💜"
        } else {
            "No hay música sonando ahora."
        }
    }

    fun resume(): String {
        val p = player
        if (p != null) {
            if (!isPlaying) {
                try { p.start() } catch (_: Exception) {}
            }
            paused = false
            ActivityController.dancing = true
            return "Sigo con la música. 💜"
        }
        return if (tracks.isEmpty()) noLibraryMessage() else playAny(false)
    }

    fun next(): String {
        if (tracks.isEmpty()) return noLibraryMessage()
        index = if (shuffle) Random.nextInt(tracks.size) else (index + 1) % tracks.size
        return playCurrent()
    }

    fun previous(): String {
        if (tracks.isEmpty()) return noLibraryMessage()
        index = (index - 1 + tracks.size) % tracks.size
        return playCurrent()
    }

    fun stop(): String {
        val was = player != null
        releasePlayer()
        return if (was) "Listo, paré la música." else "No hay música sonando ahora."
    }

    fun nowPlayingTitle(): String? = if (player != null && tracks.isNotEmpty()) tracks[index].title else null

    private fun releasePlayer() {
        try { player?.setOnCompletionListener(null) } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        ActivityController.dancing = false
    }

    private fun noLibraryMessage() =
        "Todavía no tengo música. Elegí una carpeta con «📁 Carpeta de música» en Ajustes. 💜"

    private val STOP = setOf(
        "la", "el", "los", "las", "de", "del", "un", "una", "unos", "unas", "al", "algo", "que",
        "se", "llama", "llamada", "llamado", "cancion", "canciones", "tema", "temas", "musica",
        "audio", "audios", "artista", "album", "disco", "por", "favor", "mi", "mis", "y", "con",
        "carpeta", "lista", "pista", "me", "te", "en", "a", "quiero", "escuchar"
    )

    /** Minúsculas, sin tildes, sin signos: para comparar nombres de forma tolerante. */
    fun normalize(text: String): String {
        val lower = text.lowercase(Locale("es", "ES"))
        val noAccents = Normalizer.normalize(lower, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        return noAccents.replace(Regex("[^a-z0-9ñ ]+"), " ").replace(Regex("\\s+"), " ").trim()
    }
}
