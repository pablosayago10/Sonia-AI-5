package com.sonia.ai

import android.os.Handler
import android.os.Looper
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.MessageCallback
import java.io.File

/** Qué backend usar para correr el modelo. AUTO prueba GPU y, si falla, pasa a CPU solo. */
enum class BackendPreference { AUTO, GPU, CPU }

/**
 * Envoltorio de LiteRT-LM (el runtime de Google para correr modelos de IA en el propio
 * teléfono, sin internet).
 *
 * Es un "object" (en vez de una clase normal): hay una sola instancia para toda la app,
 * y vive mientras el proceso de la app siga vivo. Por eso, si volvés a entrar a Sonia AI
 * sin que Android haya cerrado la app del todo, el modelo sigue cargado en memoria y no
 * hay que esperar de nuevo.
 */
object SoniaAIEngine {

    private var engine: Engine? = null
    private var conversation: Conversation? = null
    private var activeModelFile: File? = null
    private var activeBackendName: String = ""

    // En algunos teléfonos la GPU "carga" bien pero falla recién al mandar un mensaje
    // (por ejemplo, si al equipo le falta la librería OpenCL). Una vez que pasa eso, no
    // tiene sentido seguir intentando con GPU en esta misma sesión.
    private var gpuFailedThisSession = false

    // Instrucciones fijas para la IA (la "memoria/órdenes" que el usuario puede escribir
    // en la app, por ejemplo "Respondé siempre corto" o "Me llamo Pablo"). Se guardan acá
    // para poder recrear la conversación con ellas cada vez que se carga un modelo nuevo
    // o cuando el usuario las cambia mientras el modelo ya está cargado.
    private var systemInstruction: String? = null

    private val defaultInstruction =
        "Respondé siempre en español rioplatense, con claridad y naturalidad. " +
        "Priorizá respuestas directas y breves; ampliá cuando te lo pidan. " +
        "No inventes acciones: si no podés hacer algo, explicá la limitación."

    // Límite de largo de cada respuesta. Confirmado en la documentación oficial de
    // Google (ConversationConfig.maxOutputToken) antes de agregarlo acá. Respuestas más
    // cortas se generan más rápido, que es justo lo que necesitamos en este teléfono
    // (todo corre por CPU). 512 alcanza para respuestas de varios párrafos.
    private const val MAX_OUTPUT_TOKENS = 256

    private val mainHandler = Handler(Looper.getMainLooper())

    val isLoaded: Boolean
        get() = conversation != null

    // Nombre del backend que terminó usando ("GPU" o "CPU"), para mostrarlo en pantalla.
    val activeBackend: String
        get() = activeBackendName

    /**
     * Carga el archivo .litertlm. Tarda varios segundos (puede llegar a 10),
     * así que hay que llamarla siempre desde un hilo que no sea el principal:
     * si se llama en el hilo de la pantalla, la app se congela mientras carga.
     *
     * @param systemInstruction instrucciones fijas para la IA (puede ser null o vacío
     * para no usar ninguna). Si no se pasa, se mantiene la última que se haya guardado.
     */
    fun loadModel(
        modelFile: File,
        preference: BackendPreference = BackendPreference.AUTO,
        systemInstruction: String? = this.systemInstruction,
        onResult: (Boolean, String) -> Unit
    ) {
        this.systemInstruction = systemInstruction
        close()
        activeModelFile = modelFile

        val candidates: List<Pair<String, Backend>> = when (preference) {
            BackendPreference.CPU -> listOf("CPU" to Backend.CPU())
            BackendPreference.GPU -> listOf("GPU" to Backend.GPU())
            BackendPreference.AUTO ->
                if (gpuFailedThisSession) {
                    listOf("CPU" to Backend.CPU())
                } else {
                    listOf("GPU" to Backend.GPU(), "CPU" to Backend.CPU())
                }
        }

        for ((name, backend) in candidates) {
            if (tryLoad(modelFile, backend)) {
                activeBackendName = name
                postToMainThread { onResult(true, "Modelo cargado ✓ (usando $name)") }
                return
            }
        }

        val reason = if (preference == BackendPreference.GPU) {
            "La GPU de este teléfono no es compatible con este modelo."
        } else {
            "No se pudo cargar el modelo en este teléfono."
        }
        postToMainThread { onResult(false, reason) }
    }

    private fun tryLoad(modelFile: File, backend: Backend): Boolean {
        return try {
            val config = EngineConfig(
                modelPath = modelFile.absolutePath,
                backend = backend
            )
            val newEngine = Engine(config)
            newEngine.initialize()

            engine = newEngine
            conversation = buildConversation(newEngine)
            true
        } catch (e: Exception) {
            close(keepModelFile = true)
            false
        }
    }

    // Arma la conversación, aplicando las instrucciones fijas (si hay alguna cargada) y
    // el límite de largo de respuesta (para que conteste más rápido).
    private fun buildConversation(eng: Engine): Conversation {
        val instruction = systemInstruction?.takeIf { it.isNotBlank() } ?: defaultInstruction

        return if (instruction.isBlank()) {
            eng.createConversation(
                ConversationConfig(maxOutputToken = MAX_OUTPUT_TOKENS)
            )
        } else {
            eng.createConversation(
                ConversationConfig(
                    systemInstruction = Contents.of(instruction),
                    maxOutputToken = MAX_OUTPUT_TOKENS
                )
            )
        }
    }

    /**
     * Cambia (o borra, pasando null o vacío) las instrucciones fijas de la IA ("memoria").
     * Si ya hay un modelo cargado, se reinicia la conversación con las nuevas instrucciones
     * (sin tener que volver a cargar el archivo .litertlm entero, así que es instantáneo);
     * el historial que se ve en pantalla no se borra, solo lo que la IA tiene "en mente"
     * internamente para la próxima respuesta. Devuelve true si se pudo aplicar ya mismo.
     */
    fun updateSystemInstruction(instruction: String?): Boolean {
        systemInstruction = instruction
        val eng = engine ?: return false

        return try {
            conversation?.close()
            conversation = buildConversation(eng)
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Manda un mensaje y devuelve la respuesta completa cuando el modelo termina de
     * generarla. Si se está usando la GPU y falla recién en este paso (no al cargar),
     * se cambia solo a CPU y se reintenta ese mismo mensaje una vez, sin que el usuario
     * tenga que hacer nada.
     */
    fun sendMessage(
        text: String,
        onResponse: (String) -> Unit
    ) {
        sendMessageInternal(text, allowGpuFallback = true, onResponse)
    }

    private fun sendMessageInternal(
        text: String,
        allowGpuFallback: Boolean,
        onResponse: (String) -> Unit
    ) {
        val conv = conversation
        if (conv == null) {
            postToMainThread { onResponse("Todavía no cargué ningún modelo.") }
            return
        }

        val full = StringBuilder()

        conv.sendMessageAsync(text, object : MessageCallback {
            override fun onMessage(message: Message) {
                // En LiteRT-LM, Message.toString() devuelve Contents.toString(),
                // que concatena el texto de los fragmentos. No devuelve el objeto
                // Message completo. Cada callback trae un fragmento de la respuesta.
                full.append(message.toString())
            }

            override fun onDone() {
                val result = full.toString()
                postToMainThread { onResponse(result) }
            }

            override fun onError(throwable: Throwable) {
                val wasUsingGpu = activeBackendName == "GPU"
                val file = activeModelFile

                if (allowGpuFallback && wasUsingGpu && file != null) {
                    gpuFailedThisSession = true
                    close(keepModelFile = true)

                    if (tryLoad(file, Backend.CPU())) {
                        activeBackendName = "CPU"
                        // Reintentamos el mismo mensaje, esta vez sin permitir otro
                        // salto de GPU a CPU (para no quedar en un loop).
                        sendMessageInternal(text, allowGpuFallback = false, onResponse)
                        return
                    }
                }

                val message = "Hubo un error al responder: ${throwable.message ?: "desconocido"}"
                postToMainThread { onResponse(message) }
            }
        })
    }

    fun close(keepModelFile: Boolean = false) {
        conversation?.close()
        conversation = null
        engine?.close()
        engine = null
        activeBackendName = ""
        if (!keepModelFile) {
            activeModelFile = null
        }
    }

    // Hace que action() se ejecute en el hilo principal, sin importar desde qué
    // hilo se llamó. Es la única forma segura de tocar la pantalla de Android.
    private fun postToMainThread(action: () -> Unit) {
        mainHandler.post(action)
    }
}
