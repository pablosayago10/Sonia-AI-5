package com.sonia.ai

import android.content.Context
import android.graphics.PixelFormat
import android.opengl.GLSurfaceView
import android.os.SystemClock
import android.view.MotionEvent
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Estados del avatar. El valor (ordinal) coincide con el que espera el código nativo. */
enum class AvatarState { NEUTRAL, THINKING, TALKING }

/**
 * @param overlayMode true cuando el avatar vive en la burbuja flotante: fondo transparente,
 *   por encima de otras apps, sin gestos propios (los maneja la burbuja) y a menos cuadros.
 */
class Live2DView(context: Context, private val overlayMode: Boolean = false) :
  GLSurfaceView(context), GLSurfaceView.Renderer {

  // Con 30 fps el avatar se ve fluido y la batería/CPU del teléfono se agradecen.
  private val frameIntervalMs = if (overlayMode) 1000L / 24L else 1000L / 30L
  private var lastFrameMs = 0L

  init {
    Live2DJniBridge.setContext(context)
    setEGLContextClientVersion(2)
    setEGLConfigChooser(8, 8, 8, 8, 16, 0)
    if (overlayMode) setZOrderOnTop(true)
    holder.setFormat(PixelFormat.TRANSLUCENT)
    setRenderer(this)
    renderMode = RENDERMODE_CONTINUOUSLY
  }

  override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) { Live2DJniBridge.nativeOnSurfaceCreated() }

  override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
    Live2DJniBridge.nativeOnSurfaceChanged(width, height)
  }

  override fun onDrawFrame(gl: GL10?) {
    // Limitador de cuadros: esperamos lo que falte para completar el intervalo.
    val now = SystemClock.uptimeMillis()
    val wait = frameIntervalMs - (now - lastFrameMs)
    if (lastFrameMs != 0L && wait > 0) {
      try { Thread.sleep(wait) } catch (_: InterruptedException) {}
    }
    lastFrameMs = SystemClock.uptimeMillis()
    Live2DJniBridge.nativeOnDrawFrame()
  }

  override fun onTouchEvent(e: MotionEvent): Boolean {
    if (overlayMode) return false
    // El MotionEvent se recicla al volver de este método: copiamos TODO antes de queueEvent.
    val action = e.actionMasked
    val x = e.x
    val y = e.y
    queueEvent {
      when (action) {
        MotionEvent.ACTION_DOWN -> Live2DJniBridge.nativeOnTouchesBegan(x, y)
        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> Live2DJniBridge.nativeOnTouchesEnded(x, y)
        MotionEvent.ACTION_MOVE -> Live2DJniBridge.nativeOnTouchesMoved(x, y)
      }
    }
    return true
  }

  // Estos avisos se llaman desde MainActivity con el GL ya pausado (onPause/onStop), así
  // que no compiten con el hilo de dibujo.
  fun nativeStart() { Live2DJniBridge.nativeOnStart() }
  fun nativeStop() { Live2DJniBridge.nativeOnStop() }
  fun nativePause() { Live2DJniBridge.nativeOnPause() }
  fun nativeDestroy() { Live2DJniBridge.nativeOnDestroy() }

  /** Cambia el gesto del avatar (boca al hablar, cabeza ladeada al pensar). */
  fun setState(state: AvatarState) { Live2DJniBridge.nativeSetState(state.ordinal) }
}
