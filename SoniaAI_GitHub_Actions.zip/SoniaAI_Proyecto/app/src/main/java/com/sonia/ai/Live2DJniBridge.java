package com.sonia.ai;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/** Puente JNI entre Kotlin y el SDK nativo de Live2D (libSoniaCubism.so). */
public final class Live2DJniBridge {
  private static volatile Context context;

  public static void setContext(Context c) { context = c.getApplicationContext(); }

  /** Lista el contenido de una carpeta de assets. Nunca devuelve null (el JNI no lo controla). */
  public static String[] GetAssetList(String path) {
    Context c = context;
    if (c == null) return new String[0];
    try {
      String[] list = c.getAssets().list(path);
      return list != null ? list : new String[0];
    } catch (IOException e) {
      return new String[0];
    }
  }

  /** Lee un asset completo (en bucle: available() no garantiza el tamano real). null si no existe. */
  public static byte[] LoadFile(String path) {
    Context c = context;
    if (c == null) return null;
    try (InputStream in = c.getAssets().open(path)) {
      ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(in.available(), 1024));
      byte[] buf = new byte[64 * 1024];
      int n;
      while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
      return out.toByteArray();
    } catch (IOException e) {
      return null;
    }
  }

  public static void MoveTaskToBack() {}

  public static native void nativeOnStart();
  public static native void nativeOnPause();
  public static native void nativeOnStop();
  public static native void nativeOnDestroy();
  public static native void nativeOnSurfaceCreated();
  public static native void nativeOnSurfaceChanged(int w, int h);
  public static native void nativeOnDrawFrame();
  public static native void nativeOnTouchesBegan(float x, float y);
  public static native void nativeOnTouchesEnded(float x, float y);
  public static native void nativeOnTouchesMoved(float x, float y);
  /** 0 = neutral, 1 = pensando, 2 = hablando. */
  public static native void nativeSetState(int state);
  /** Emocion de la cara: ver AvatarEmotion. */
  public static native void nativeSetEmotion(int emotion);
  /** Actividad: ver AvatarActivity. */
  public static native void nativeSetActivity(int activity);
  /** Interruptor de una pieza extra del modelo (0..6). */
  public static native void nativeSetEffect(int index, boolean on);
  public static native void nativeSetClearColor(float r, float g, float b, float a);

  static { System.loadLibrary("SoniaCubism"); }
}
