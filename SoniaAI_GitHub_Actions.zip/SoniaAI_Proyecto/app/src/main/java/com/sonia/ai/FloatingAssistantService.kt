package com.sonia.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.text.TextUtils
import java.io.File
import java.util.Locale
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Burbuja flotante con el avatar Live2D, un mini teclado y el micrófono.
 *
 * Como el renderer nativo es único (lo comparten esta burbuja y la pantalla principal),
 * la burbuja solo se muestra cuando la app está en segundo plano. Al volver a la app se
 * quita (MainActivity avisa con [setAppForeground]) y al salir vuelve a aparecer.
 *
 * - Tocar el avatar abre la app. Mantenerlo pulsado cierra la burbuja. Se arrastra.
 * - Mini teclado y micrófono: escribís (➤) o hablás (🎤) y Sonia contesta en un globito, SIN abrir la app.
 * - Micrófono: abre la app y usa el reconocedor de voz de Android.
 */
class FloatingAssistantService : Service() {

    private lateinit var windowManager: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var overlay: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var avatarView: Live2DView? = null
    private var miniInput: EditText? = null
    private var replyView: TextView? = null
    private var micBtn: TextView? = null
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var busy = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val hideReply = Runnable { replyView?.visibility = View.GONE }
    private val endTalking = Runnable { setAvatar(AvatarState.NEUTRAL) }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        IdleDirector.start()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        // Si la app está abierta no mostramos la burbuja: aparece al salir de la app.
        if (!appForeground) showOverlay()
    }

    /** Edita el texto de la mini entrada con un EditText que detecta el botón "atrás". */
    private inner class OverlayEditText(context: Context) : EditText(context) {
        override fun onKeyPreIme(keyCode: Int, event: KeyEvent): Boolean {
            if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                disableTyping()
                return true
            }
            return super.onKeyPreIme(keyCode, event)
        }
    }

    private fun showOverlay() {
        if (overlay != null) return

        // Fondo transparente para el avatar (la pantalla principal vuelve a poner el suyo).
        Live2DJniBridge.nativeSetClearColor(0f, 0f, 0f, 0f)

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        // --- Avatar ---
        val avatar = Live2DView(this, overlayMode = true)
        avatarView = avatar
        val slot = FrameLayout(this)
        slot.addView(avatar, FrameLayout.LayoutParams(-1, -1))
        column.addView(slot, LinearLayout.LayoutParams(dp(150), dp(190)))
        attachDragAndTap(slot)

        // --- Globo con la respuesta de Sonia (aparece al contestar, se esconde solo) ---
        val reply = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            maxLines = 10
            ellipsize = TextUtils.TruncateAt.END
            visibility = View.GONE
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.argb(235, 60, 40, 90))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.rgb(178, 135, 220))
            }
        }
        replyView = reply
        column.addView(reply, LinearLayout.LayoutParams(dp(230), WRAP).apply { bottomMargin = dp(6) })

        // --- Fila inferior: mini teclado + enviar + micrófono ---
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(4), dp(4), dp(4))
            background = GradientDrawable().apply {
                setColor(Color.argb(230, 35, 25, 48))
                cornerRadius = dp(26).toFloat()
                setStroke(dp(1), Color.rgb(178, 135, 220))
            }
        }

        val input = OverlayEditText(this).apply {
            hint = "Escribile a Sonia..."
            setHintTextColor(Color.argb(150, 255, 255, 255))
            setTextColor(Color.WHITE)
            textSize = 14f
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            background = null
            setPadding(0, dp(6), dp(6), dp(6))
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendTypedText()
                    true
                } else false
            }
            // Al tocar la caja, la ventana pasa a poder recibir teclado.
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_DOWN) enableTyping()
                false
            }
        }
        miniInput = input
        pill.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f))

        pill.addView(roundButton("➤") { sendTypedText() }, LinearLayout.LayoutParams(dp(40), dp(40)))
        val mic = roundButton("🎤") { onMicClicked() }
        micBtn = mic
        pill.addView(mic, LinearLayout.LayoutParams(dp(40), dp(40)))

        column.addView(pill, LinearLayout.LayoutParams(dp(230), WRAP))

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(120)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
        params = lp

        try {
            avatar.nativeStart()
            windowManager.addView(column, lp)
            overlay = column
        } catch (e: Exception) {
            avatarView = null
            miniInput = null
            replyView = null
            params = null
            Toast.makeText(this, "No pude mostrar el control flotante.", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun hideOverlay() {
        val view = overlay ?: return
        disableTyping()
        stopListening()
        // Primero paramos el dibujo (espera a que el hilo de GL se detenga) y recién
        // después sacamos la vista, para no pelear con la pantalla principal por la GPU.
        avatarView?.let {
            it.onPause()
            it.nativePause()
        }
        try { windowManager.removeView(view) } catch (_: Exception) {}
        handler.removeCallbacks(hideReply)
        overlay = null
        avatarView = null
        miniInput = null
        replyView = null
        micBtn = null
        params = null
    }

    // --- Gestos sobre el avatar: arrastrar, tocar (abrir app), mantener (cerrar) ---

    private fun attachDragAndTap(target: View) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var initialX = 0
        var initialY = 0
        var startX = 0f
        var startY = 0f
        var dragging = false
        var longPressed = false
        val longPress = Runnable {
            longPressed = true
            stopSelf()
        }

        target.setOnTouchListener { _, event ->
            val lp = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = lp.x
                    initialY = lp.y
                    startX = event.rawX
                    startY = event.rawY
                    dragging = false
                    longPressed = false
                    handler.postDelayed(longPress, 900)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - startX
                    val dy = event.rawY - startY
                    if (!dragging && (kotlin.math.abs(dx) > slop || kotlin.math.abs(dy) > slop)) {
                        dragging = true
                        handler.removeCallbacks(longPress)
                    }
                    if (dragging) {
                        lp.x = initialX - dx.toInt()
                        lp.y = initialY + dy.toInt()
                        overlay?.let { try { windowManager.updateViewLayout(it, lp) } catch (_: Exception) {} }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    if (!dragging && !longPressed) {
                        disableTyping()
                        val open = Intent(this, MainActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        startActivity(open)
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    true
                }
                else -> false
            }
        }
    }

    // --- Mini teclado ---

    private fun enableTyping() {
        val view = overlay ?: return
        val lp = params ?: return
        lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        try { windowManager.updateViewLayout(view, lp) } catch (_: Exception) { return }
        val input = miniInput ?: return
        input.post {
            input.requestFocus()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun disableTyping() {
        val view = overlay ?: return
        val lp = params ?: return
        val input = miniInput
        if (input != null) {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(input.windowToken, 0)
            input.clearFocus()
        }
        if ((lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            try { windowManager.updateViewLayout(view, lp) } catch (_: Exception) {}
        }
    }

    private fun sendTypedText() {
        val input = miniInput ?: return
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.text.clear()
        disableTyping()
        answerInBubble(text)
    }

    // --- Responder desde la burbuja, sin abrir la app ---

    private fun setAvatar(state: AvatarState) {
        avatarView?.setState(state)
    }

    private fun showReply(text: String, holdMs: Long = 0) {
        val v = replyView ?: return
        v.text = text
        v.visibility = View.VISIBLE
        handler.removeCallbacks(hideReply)
        val visibleFor = (6000L + text.length * 70L).coerceAtMost(30000L).coerceAtLeast(holdMs)
        handler.postDelayed(hideReply, visibleFor)
    }

    private fun answerInBubble(text: String) {
        IdleDirector.touch()
        if (busy) {
            showReply("Esperá un momento, todavía estoy respondiendo lo anterior. 💜")
            return
        }

        // 1) Órdenes del teléfono (abrir apps, música, volumen...): no necesitan la IA.
        val action = try { PhoneActions.handle(this, text) } catch (_: Exception) { null }
        if (action != null) {
            EmotionController.react(action)
            showReply(action)
            setAvatar(AvatarState.TALKING)
            handler.removeCallbacks(endTalking)
            handler.postDelayed(endTalking, 1800)
            return
        }

        // 2) Conversación con la IA. Si el modelo no está en memoria, lo cargamos solo.
        busy = true
        ActivityController.working = true
        setAvatar(AvatarState.THINKING)
        showReply("Pensando... 💭", holdMs = 60000)

        if (SoniaAIEngine.isLoaded) {
            askEngine(text)
            return
        }
        val path = getSharedPreferences("sonia_prefs", MODE_PRIVATE).getString("model_path", null)
        val file = path?.let { File(it) }
        if (file == null || !file.exists()) {
            finishReply("Todavía no cargué mi modelo. Abrí la app y cargalo una vez. 💜")
            return
        }
        showReply("Despertando mi cerebro, un momento... 🧠", holdMs = 120000)
        val prefs = getSharedPreferences("sonia_prefs", MODE_PRIVATE)
        val backend = try {
            BackendPreference.valueOf(prefs.getString("backend_pref", "CPU") ?: "CPU")
        } catch (_: Exception) { BackendPreference.CPU }
        val instruction = prefs.getString("system_instruction", null)
        Thread {
            SoniaAIEngine.loadModel(file, backend, instruction) { ok, msg ->
                if (ok) askEngine(text) else finishReply(msg)
            }
        }.start()
    }

    private fun askEngine(text: String) {
        try {
            SoniaAIEngine.sendMessage(text) { raw ->
                val clean = raw.replace(Regex("(?s)<think>.*?</think>"), "").trim()
                finishReply(if (clean.isEmpty()) "No supe qué contestarte. 💜" else clean)
            }
        } catch (e: Exception) {
            finishReply("Hubo un error al responder.")
        }
    }

    private fun finishReply(reply: String) {
        busy = false
        ActivityController.working = false
        showReply(reply)
        val talkMs = (900L + reply.length * 55L).coerceAtMost(15000L)
        setAvatar(AvatarState.TALKING)
        EmotionController.react(reply, talkMs + 3000)
        handler.removeCallbacks(endTalking)
        handler.postDelayed(endTalking, talkMs)
        speak(reply)
    }

    private fun speak(text: String) {
        val voiceOn = getSharedPreferences("sonia_prefs", MODE_PRIVATE).getBoolean("voice_enabled", true)
        if (!voiceOn) return
        val engine = tts
        if (engine == null) {
            tts = TextToSpeech(applicationContext) { status ->
                ttsReady = status == TextToSpeech.SUCCESS
                if (ttsReady) {
                    tts?.setLanguage(Locale("es", "ES"))
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sonia_bubble")
                }
            }
        } else if (ttsReady) {
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sonia_bubble")
        }
    }

    // --- Micrófono desde la burbuja (sin abrir la app) ---

    private fun onMicClicked() {
        disableTyping()
        IdleDirector.touch()
        if (listening) {
            stopListening()
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            showReply("Necesito permiso para usar el micrófono. Aceptalo en la ventanita que se abre y después tocá 🎤 de nuevo. 💜", 8000)
            try {
                startActivity(Intent(this, PermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            showReply("Tu teléfono no tiene reconocimiento de voz disponible. Escribime con el teclado. 💜")
            return
        }
        startListening()
    }

    private fun startListening() {
        try {
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { showReply("Te escucho... 🎤", 20000) }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}

                override fun onPartialResults(partialResults: Bundle?) {
                    val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) showReply("🎤 $t", 20000)
                }

                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    stopListening()
                    if (text.isNullOrBlank()) {
                        showReply("No te escuché bien, probá de nuevo. 💜")
                    } else {
                        answerInBubble(text.trim())
                    }
                }

                override fun onError(error: Int) {
                    stopListening()
                    showReply(
                        when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                                "No te escuché, probá de nuevo. 💜"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                                "Me falta el permiso de micrófono. Abrí la app y tocá 🎤 una vez para dárselo."
                            else ->
                                "No pude usar el micrófono desde la burbuja (Android a veces lo bloquea en segundo plano). Escribime con el teclado. 💜"
                        }
                    )
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-AR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            listening = true
            ActivityController.listening = true
            micBtn?.text = "⏹"
            r.startListening(i)
        } catch (e: Exception) {
            stopListening()
            showReply("No pude iniciar el micrófono. Escribime con el teclado. 💜")
        }
    }

    private fun stopListening() {
        val r = recognizer
        recognizer = null
        if (r != null) {
            try { r.cancel() } catch (_: Exception) {}
            try { r.destroy() } catch (_: Exception) {}
        }
        listening = false
        ActivityController.listening = false
        micBtn?.text = "🎤"
    }

    private fun roundButton(label: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(120, 75, 165))
            }
            setOnClickListener { onClick() }
        }

    // --- Notificación ---

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Sonia AI flotante",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this,
            20,
            Intent(this, FloatingAssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID)
        else
            @Suppress("DEPRECATION")
            Notification.Builder(this)

        return builder
            .setContentTitle("Sonia AI está activa")
            .setContentText("Tocá a Sonia para abrir la app, o escribile desde la burbuja")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Cerrar", stopIntent).build())
            .build()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(endTalking)
        tts?.stop()
        tts?.shutdown()
        tts = null
        hideOverlay()
        instance = null
        isRunning = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val WRAP = android.view.ViewGroup.LayoutParams.WRAP_CONTENT

        @Volatile var isRunning: Boolean = false
            private set
        @Volatile private var instance: FloatingAssistantService? = null
        @Volatile private var appForeground: Boolean = false

        private const val CHANNEL_ID = "sonia_floating"
        private const val NOTIFICATION_ID = 721
        const val ACTION_STOP = "com.sonia.ai.STOP_FLOATING"
        const val ACTION_SEND_TEXT = "com.sonia.ai.SEND_TEXT"
        const val EXTRA_TEXT = "text"

        /**
         * MainActivity avisa si está a la vista. Hay que llamarlo desde el hilo principal.
         * true -> se quita la burbuja (el avatar pasa a la pantalla principal);
         * false -> se muestra la burbuja si el servicio está activo.
         */
        fun setAppForeground(foreground: Boolean) {
            appForeground = foreground
            val service = instance ?: return
            if (foreground) service.hideOverlay() else service.showOverlay()
        }
    }
}
