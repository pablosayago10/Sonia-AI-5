package com.sonia.ai

import android.app.Activity
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.provider.MediaStore
import android.content.pm.PackageManager
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import android.app.AlertDialog
import android.content.Intent

import android.graphics.Color
import android.graphics.drawable.GradientDrawable

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.database.Cursor
import android.provider.OpenableColumns
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var scroll: ScrollView
    private lateinit var messages: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var loadButton: Button
    private lateinit var sendButton: Button
    private lateinit var micButton: Button
    private lateinit var autoButton: Button
    private lateinit var gpuButton: Button
    private lateinit var cpuButton: Button

    // --- Panel lateral de chats (como la lista de conversaciones de Claude) ---
    private lateinit var scrim: View
    private lateinit var sidebar: LinearLayout
    private lateinit var chatListContainer: LinearLayout
    private var sidebarOpen = false

    private val ioExecutor = Executors.newSingleThreadExecutor()

    private val whoList = ArrayList<String>()
    private val bodyList = ArrayList<String>()

    private var modelReady = false
    private var currentModelFile: File? = null
    private var currentChatId: String = ""

    // Tu TCL 50 5G usa un MediaTek Dimensity 6100+ con GPU Mali-G57: ese chip no trae
    // soporte de OpenCL, que es lo que esta IA necesita para usar la GPU. Por eso
    // arrancamos directo en CPU en vez de perder tiempo probando GPU primero.
    private var currentPreference = BackendPreference.CPU

    // Burbuja de "Sonia está pensando...", mientras esperamos la respuesta.
    private var typingBubble: View? = null

    // --- Voz (texto a voz de Android, offline, viene de fábrica) ---
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var voiceEnabled = true
    private lateinit var voiceButton: Button

    // --- Avatar tipo "VTuber" (cara que cambia según el estado) ---
    private lateinit var avatarView: Live2DView
    private val mainHandlerUi = Handler(Looper.getMainLooper())

    // Reproducción de archivos de audio elegidos por el usuario (SAF).
    private lateinit var musicFolderButton: Button
    private lateinit var floatingButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        currentPreference = readSavedPreference()
        migrateOldHistoryIfNeeded()

        voiceEnabled = modelPrefs().getBoolean(KEY_VOICE_ENABLED, true)
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setLanguage(Locale("es", "ES"))
                pickBestSpanishVoice()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        mainHandlerUi.post { setAvatarState(AvatarState.NEUTRAL) }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        mainHandlerUi.post { setAvatarState(AvatarState.NEUTRAL) }
                    }
                })
            }
        }

        val pad = intArrayOf(dp(16), dp(16), dp(16), dp(12))

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad[0], pad[1], pad[2], pad[3])
            setBackgroundColor(Color.rgb(248, 245, 252))

            setOnApplyWindowInsetsListener { v, insets ->
                val sys = systemInsets(insets)
                v.setPadding(
                    pad[0] + sys[0],
                    pad[1] + sys[1],
                    pad[2] + sys[2],
                    pad[3] + sys[3]
                )
                insets
            }
        }

        // Fila de arriba: botón de menú (abre la lista de chats), título y botón de
        // chat nuevo. Así queda parecida a la barra de arriba de un chat de verdad.
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val menuButton = Button(this).apply {
            text = "☰"
            textSize = 16f
            setOnClickListener { toggleSidebar() }
        }
        topRow.addView(menuButton)

        val titleColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }

        val title = TextView(this).apply {
            text = "Sonia AI 💜"
            textSize = 24f
            setTextColor(Color.rgb(92, 45, 135))
            gravity = Gravity.CENTER
        }
        titleColumn.addView(title)

        val subtitle = TextView(this).apply {
            text = "Tu asistente personal"
            textSize = 13f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
        }
        titleColumn.addView(subtitle)

        topRow.addView(
            titleColumn,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )

        val newChatButton = Button(this).apply {
            text = "＋"
            textSize = 16f
            setOnClickListener { startNewChat() }
        }
        topRow.addView(newChatButton)

        page.addView(topRow)

        // Línea fina debajo del título, como en una barra superior de chat normal.
        val divider = View(this).apply {
            setBackgroundColor(Color.rgb(225, 215, 235))
        }
        page.addView(divider, LinearLayout.LayoutParams(-1, dp(1)).apply {
            topMargin = dp(10)
            bottomMargin = dp(10)
        })

        // Avatar de Sonia: modelo Live2D 2D (xl). Parpadea y respira solo; al pensar
        // ladea la cabeza y mira hacia arriba, y al hablar mueve la boca.
        avatarView = Live2DView(this)
        page.addView(
            avatarView,
            LinearLayout.LayoutParams(avatarWidthPx(), avatarHeightPx()).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(8)
            }
        )

        scroll = ScrollView(this)

        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(10), dp(2), dp(6))
        }

        scroll.addView(messages)
        page.addView(
            scroll,
            LinearLayout.LayoutParams(-1, 0, 1f)
        )

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        input = EditText(this).apply {
            hint = "Escribile a Sonia..."
            textSize = 16f
            isSingleLine = true
        }

        row.addView(
            input,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        )

        micButton = Button(this).apply {
            text = "🎤"
            setOnClickListener { openSpeechRecognizer() }
        }
        row.addView(micButton)

        sendButton = Button(this).apply {
            text = "Enviar"
            setOnClickListener {
                val message = input.text.toString().trim()
                if (message.isNotEmpty()) {
                    input.text.clear()
                    sendUserMessage(message)
                }
            }
        }

        row.addView(sendButton)
        page.addView(row)

        // --- Panel lateral de chats, estilo barra lateral de Claude ---

        scrim = View(this).apply {
            setBackgroundColor(Color.argb(140, 0, 0, 0))
            visibility = View.GONE
            setOnClickListener { closeSidebar() }
        }

        sidebar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(16))
            setBackgroundColor(Color.rgb(255, 255, 255))
            visibility = View.GONE
        }

        sidebar.setOnApplyWindowInsetsListener { v, insets ->
            val sys = systemInsets(insets)
            v.setPadding(dp(14) + sys[0], dp(16) + sys[1], dp(14), dp(16) + sys[3])
            insets
        }

        val sidebarTitle = TextView(this).apply {
            text = "Tus chats"
            textSize = 18f
            setTextColor(Color.rgb(92, 45, 135))
        }
        sidebar.addView(sidebarTitle)

        val sidebarNewChat = Button(this).apply {
            text = "＋ Nuevo chat"
            textSize = 13f
            setOnClickListener { startNewChat() }
        }
        sidebar.addView(sidebarNewChat, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(10)
            bottomMargin = dp(6)
        })

        // Todo el panel (lista de chats + ajustes) scrollea junto, en una sola
        // columna, para que quepa bien en pantalla sin importar cuántos chats tengas.
        val sidebarScroll = ScrollView(this)
        val sidebarContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        sidebarScroll.addView(sidebarContent)
        sidebar.addView(sidebarScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        chatListContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        sidebarContent.addView(chatListContainer)

        val settingsDivider = View(this).apply {
            setBackgroundColor(Color.rgb(225, 215, 235))
        }
        sidebarContent.addView(settingsDivider, LinearLayout.LayoutParams(-1, dp(1)).apply {
            topMargin = dp(14)
            bottomMargin = dp(10)
        })

        val settingsTitle = TextView(this).apply {
            text = "⚙️ Ajustes"
            textSize = 16f
            setTextColor(Color.rgb(92, 45, 135))
        }
        sidebarContent.addView(settingsTitle, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(8)
        })

        loadButton = Button(this).apply {
            text = "📂 Cargar modelo"
            textSize = 12f
            setOnClickListener { openModelPicker() }
        }
        sidebarContent.addView(loadButton, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(6)
        })

        status = TextView(this).apply {
            text = "Modelo de IA no cargado"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }
        sidebarContent.addView(status, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(10)
        })

        // Selector de backend: Auto (recomendado), GPU a la fuerza, CPU a la fuerza.
        val backendRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        autoButton = Button(this).apply {
            text = "Auto"
            textSize = 12f
            setOnClickListener { changeBackend(BackendPreference.AUTO) }
        }
        gpuButton = Button(this).apply {
            text = "GPU"
            textSize = 12f
            setOnClickListener { changeBackend(BackendPreference.GPU) }
        }
        cpuButton = Button(this).apply {
            text = "CPU"
            textSize = 12f
            setOnClickListener { changeBackend(BackendPreference.CPU) }
        }
        backendRow.addView(autoButton)
        backendRow.addView(gpuButton)
        backendRow.addView(cpuButton)
        sidebarContent.addView(backendRow, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(10)
        })
        highlightBackendButtons()

        val memoryButton = Button(this).apply {
            text = "🧠 Memoria / Instrucciones"
            textSize = 12f
            setOnClickListener { openMemoryDialog() }
        }
        sidebarContent.addView(memoryButton, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(6)
        })

        voiceButton = Button(this).apply {
            textSize = 12f
            setOnClickListener { toggleVoice() }
        }
        sidebarContent.addView(voiceButton, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(6)
        })
        updateVoiceButtonText()

        val sizeLabel = TextView(this).apply { textSize = 12f }
        val sizeBar = android.widget.SeekBar(this).apply {
            max = 80 // 70% .. 150%
            progress = avatarScalePercent() - 70
            setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: android.widget.SeekBar?, value: Int, fromUser: Boolean) {
                    sizeLabel.text = "🧍 Tamaño de Sonia: ${value + 70}%"
                    if (fromUser) {
                        modelPrefs().edit().putInt(KEY_AVATAR_SCALE, value + 70).apply()
                        applyAvatarSize()
                    }
                }
                override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
            })
        }
        sizeLabel.text = "🧍 Tamaño de Sonia: ${avatarScalePercent()}%"
        sidebarContent.addView(sizeLabel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        sidebarContent.addView(sizeBar, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })

        floatingButton = Button(this).apply {
            text = "🫧 Activar avatar flotante"
            textSize = 12f
            setOnClickListener { toggleFloatingAssistant() }
        }
        sidebarContent.addView(floatingButton, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(6)
        })
        updateFloatingButtonText()

        musicFolderButton = Button(this).apply {
            text = "📁 Carpeta de música"
            textSize = 12f
            setOnClickListener { chooseMusicFolder() }
        }
        sidebarContent.addView(musicFolderButton, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(6)
        })
        MusicController.init(this)
        if (MusicController.hasLibrary) {
            onMusicFolderScanned(MusicController.trackCount, announce = false)
        } else {
            MusicController.restoreFolder(this) { count -> onMusicFolderScanned(count, announce = false) }
        }

        // --- Expresiones de la cara ---
        val emoLabel = TextView(this).apply {
            text = "🎭 Expresión de Sonia"
            textSize = 12f
        }
        sidebarContent.addView(emoLabel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val emoItems: List<Pair<String, AvatarEmotion?>> =
            listOf<Pair<String, AvatarEmotion?>>("Auto" to null) +
                AvatarEmotion.values().map { it.emoji to it }
        for (chunk in emoItems.chunked(5)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((label, emo) in chunk) {
                val b = Button(this).apply {
                    text = label
                    textSize = 13f
                    minWidth = 0
                    minimumWidth = 0
                    setOnClickListener {
                        if (emo == null) EmotionController.setAuto() else EmotionController.setManual(emo)
                    }
                }
                row.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
            }
            sidebarContent.addView(row, LinearLayout.LayoutParams(-1, -2))
        }

        // --- Efectos del modelo (experimental): interruptores de las piezas extra que trae el modelo ---
        val fxLabel = TextView(this).apply {
            text = "✨ Efectos del modelo (prueba)"
            textSize = 12f
        }
        sidebarContent.addView(fxLabel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val fxNames = listOf("1", "2", "9", "10", "yy1", "yy2", "fz")
        for (chunk in fxNames.withIndex().toList().chunked(4)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((idx, name) in chunk) {
                val b = Button(this).apply {
                    text = name
                    textSize = 12f
                    minWidth = 0
                    minimumWidth = 0
                    var on = false
                    setOnClickListener {
                        on = !on
                        alpha = if (on) 1f else 0.6f
                        Live2DJniBridge.nativeSetEffect(idx, on)
                    }
                    alpha = 0.6f
                }
                row.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
            }
            sidebarContent.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        sidebarContent.addView(View(this), LinearLayout.LayoutParams(-1, dp(40)))


        root = FrameLayout(this)
        root.addView(page, FrameLayout.LayoutParams(-1, -1))
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        root.addView(
            sidebar,
            FrameLayout.LayoutParams(dp(280), -1, Gravity.START)
        )

        val savedWho = savedInstanceState?.getStringArrayList(KEY_WHO)
        val savedBody = savedInstanceState?.getStringArrayList(KEY_BODY)
        val savedChatId = savedInstanceState?.getString(KEY_CURRENT_CHAT_ID)

        if (savedWho != null && savedBody != null && savedChatId != null &&
            savedWho.size == savedBody.size && savedWho.isNotEmpty()
        ) {
            // Veníamos de rotar la pantalla o algo parecido: restauramos de ahí.
            currentChatId = savedChatId
            for (i in savedWho.indices) {
                addMessage(savedWho[i], savedBody[i])
            }
        } else {
            openLastOrNewChat()
        }

        refreshChatList()

        setContentView(root)
        if (intent?.action == ACTION_START_VOICE) {
            root.postDelayed({ openSpeechRecognizer() }, 350)
        }
        handleIncomingText(intent)
        watchKeyboardToShrinkAvatar()

        // El modelo vive en SoniaAIEngine, que es un "object": si ya estaba cargado de
        // antes (por ejemplo, volviste a entrar sin que Android cerrara la app del
        // todo), lo usamos directo y no hacemos esperar de nuevo a nadie.
        if (SoniaAIEngine.isLoaded) {
            modelReady = true
            status.text = "Modelo cargado ✓ (usando ${SoniaAIEngine.activeBackend})"
            loadButton.text = "Modelo cargado ✓"
        } else {
            // Si no, nos fijamos si la última vez se había cargado un modelo y, de ser
            // así, lo volvemos a cargar solos (sin que haga falta elegir el archivo de
            // nuevo). Esto solo pasa una vez por cada vez que Android mata la app del
            // todo; mientras siga viva, el paso de arriba ya alcanza.
            val savedPath = modelPrefs().getString(KEY_MODEL_PATH, null)
            val savedModelFile = savedPath?.let { File(it) }

            if (savedModelFile != null && savedModelFile.exists()) {
                currentModelFile = savedModelFile
                status.text = "Cargando el último modelo que usaste..."
                loadButton.isEnabled = false

                val savedInstruction = modelPrefs().getString(KEY_SYSTEM_INSTRUCTION, null)

                ioExecutor.execute {
                    SoniaAIEngine.loadModel(
                        savedModelFile,
                        currentPreference,
                        savedInstruction
                    ) { success, message ->
                        modelReady = success
                        status.text = message
                        loadButton.isEnabled = true
                        loadButton.text = if (success) "Modelo cargado ✓" else "📂 Cargar modelo"
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == ACTION_START_VOICE) {
            root.postDelayed({ openSpeechRecognizer() }, 250)
        }
        handleIncomingText(intent)
    }

    // Texto escrito en el mini teclado de la burbuja flotante. Si el modelo todavía se
    // está cargando, esperamos (hasta ~25 s) antes de enviarlo.
    private fun handleIncomingText(intent: Intent?) {
        if (intent?.action != FloatingAssistantService.ACTION_SEND_TEXT) return
        val text = intent.getStringExtra(FloatingAssistantService.EXTRA_TEXT)?.trim().orEmpty()
        if (text.isEmpty()) return
        // Para que un giro de pantalla no lo reenvíe.
        intent.action = null
        // Pequeña espera: así, si hay que recargar el modelo, ya está en marcha.
        root.postDelayed({ trySendIncoming(text, 0) }, 700)
    }

    private fun trySendIncoming(text: String, attempt: Int) {
        // loadButton está desactivado mientras el modelo se carga: en ese caso esperamos.
        if (modelReady || attempt >= 50 || loadButton.isEnabled) {
            sendUserMessage(text)
        } else {
            root.postDelayed({ trySendIncoming(text, attempt + 1) }, 500)
        }
    }

    // Con el teclado abierto, el avatar grande se achica para que quede lugar para el chat.
    private var avatarCompact = false

    private fun watchKeyboardToShrinkAvatar() {
        root.viewTreeObserver.addOnGlobalLayoutListener {
            val r = android.graphics.Rect()
            root.getWindowVisibleDisplayFrame(r)
            val keyboardOpen = root.rootView.height - r.height() > dp(150)
            if (keyboardOpen != avatarCompact && ::avatarView.isInitialized) {
                avatarCompact = keyboardOpen
                applyAvatarSize()
            }
        }
    }

    private fun avatarScalePercent(): Int =
        modelPrefs().getInt(KEY_AVATAR_SCALE, 100).coerceIn(70, 150)

    // Tamaño del avatar según el ajuste (70%..150%), sin pasarse de la pantalla.
    private fun avatarWidthPx(): Int {
        val w = dp(AVATAR_W_DP) * avatarScalePercent() / 100
        return w.coerceAtMost(resources.displayMetrics.widthPixels)
    }

    private fun avatarHeightPx(): Int {
        val h = dp(AVATAR_H_DP) * avatarScalePercent() / 100
        return h.coerceAtMost((resources.displayMetrics.heightPixels * 0.6f).toInt())
    }

    private fun applyAvatarSize() {
        if (!::avatarView.isInitialized) return
        val lp = avatarView.layoutParams as LinearLayout.LayoutParams
        if (avatarCompact) {
            lp.width = dp(AVATAR_COMPACT_W_DP)
            lp.height = dp(AVATAR_COMPACT_H_DP)
        } else {
            lp.width = avatarWidthPx()
            lp.height = avatarHeightPx()
        }
        avatarView.layoutParams = lp
    }

    private fun changeBackend(preference: BackendPreference) {
        currentPreference = preference
        modelPrefs().edit().putString(KEY_BACKEND_PREF, preference.name).apply()
        highlightBackendButtons()

        val file = currentModelFile
        if (file == null || !file.exists()) {
            // Todavía no hay modelo cargado: la preferencia se va a usar la próxima vez
            // que se cargue uno.
            return
        }

        status.text = "Cambiando a ${preference.name}..."
        loadButton.isEnabled = false

        ioExecutor.execute {
            SoniaAIEngine.loadModel(file, preference) { success, message ->
                modelReady = success
                status.text = message
                loadButton.isEnabled = true
            }
        }
    }

    private fun highlightBackendButtons() {
        val selected = Color.rgb(92, 45, 135)
        val normal = Color.rgb(220, 210, 232)

        autoButton.setBackgroundColor(if (currentPreference == BackendPreference.AUTO) selected else normal)
        gpuButton.setBackgroundColor(if (currentPreference == BackendPreference.GPU) selected else normal)
        cpuButton.setBackgroundColor(if (currentPreference == BackendPreference.CPU) selected else normal)

        autoButton.setTextColor(if (currentPreference == BackendPreference.AUTO) Color.WHITE else Color.DKGRAY)
        gpuButton.setTextColor(if (currentPreference == BackendPreference.GPU) Color.WHITE else Color.DKGRAY)
        cpuButton.setTextColor(if (currentPreference == BackendPreference.CPU) Color.WHITE else Color.DKGRAY)
    }

    private fun readSavedPreference(): BackendPreference {
        val saved = modelPrefs().getString(KEY_BACKEND_PREF, null) ?: return BackendPreference.CPU
        return try {
            BackendPreference.valueOf(saved)
        } catch (e: Exception) {
            BackendPreference.CPU
        }
    }

    private fun openModelPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }

        startActivityForResult(intent, REQUEST_MODEL)
    }

    @Deprecated("Usamos el selector de documentos de Android")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_SPEECH) {
            if (resultCode == RESULT_OK) {
                val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                val spoken = results?.firstOrNull()?.trim()
                if (!spoken.isNullOrEmpty()) {
                    sendUserMessage(spoken)
                }
            }
            return
        }

        if (requestCode == REQUEST_MUSIC_FOLDER && resultCode == RESULT_OK) {
            val tree = data?.data ?: return
            musicFolderButton.text = "📁 Leyendo carpeta..."
            MusicController.loadFolder(this, tree) { count -> onMusicFolderScanned(count, announce = true) }
            return
        }

        if (requestCode == REQUEST_AUDIO && resultCode == RESULT_OK) {
            val picked = data?.clipData
            val uris = ArrayList<Uri>()
            if (picked != null) {
                for (i in 0 until picked.itemCount) uris.add(picked.getItemAt(i).uri)
            } else {
                data?.data?.let { uris.add(it) }
            }
            if (uris.isNotEmpty()) {
                val grantFlags = (data?.flags ?: 0) and Intent.FLAG_GRANT_READ_URI_PERMISSION
                if (grantFlags != 0) {
                    uris.forEach { uri ->
                        try { contentResolver.takePersistableUriPermission(uri, grantFlags) }
                        catch (_: Exception) {}
                    }
                }
                MusicController.setPicked(this, uris)
                addMessage("Sonia", MusicController.playAny(false))
            }
            return
        }

        if (requestCode != REQUEST_MODEL ||
            resultCode != RESULT_OK
        ) return

        val uri: Uri = data?.data ?: return
        val fileName = getDisplayName(uri)

        if (fileName == null ||
            !fileName.endsWith(".litertlm", ignoreCase = true)
        ) {
            Toast.makeText(
                this,
                "Seleccioná un archivo .litertlm",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        loadButton.isEnabled = false
        status.text = "Copiando modelo..."

        ioExecutor.execute {
            try {
                val modelDir = File(filesDir, "models")
                if (!modelDir.exists()) {
                    modelDir.mkdirs()
                }

                val destination = File(
                    modelDir,
                    "Qwen3-0.6B.litertlm"
                )

                val stream = contentResolver.openInputStream(uri)
                    ?: throw Exception("No se pudo abrir el archivo.")

                stream.use { inputStream ->
                    destination.outputStream().buffered().use { output ->
                        inputStream.buffered().copyTo(output)
                    }
                }

                runOnUiThread {
                    status.text = "Cargando inteligencia artificial..."
                }

                currentModelFile = destination
                val savedInstruction = modelPrefs().getString(KEY_SYSTEM_INSTRUCTION, null)

                SoniaAIEngine.loadModel(destination, currentPreference, savedInstruction) { success, message ->
                    modelReady = success
                    status.text = message
                    loadButton.isEnabled = true

                    if (success) {
                        loadButton.text = "Modelo cargado ✓"
                        // Guardamos dónde quedó este archivo para la próxima vez que
                        // se abra la app desde cero (después de que Android la haya
                        // cerrado del todo): así no hay que elegirlo de nuevo.
                        modelPrefs().edit()
                            .putString(KEY_MODEL_PATH, destination.absolutePath)
                            .apply()
                    } else {
                        loadButton.text = "📂 Cargar modelo"
                    }

                    Toast.makeText(
                        this,
                        message,
                        Toast.LENGTH_LONG
                    ).show()
                }

            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Error al copiar el modelo"
                    loadButton.isEnabled = true

                    Toast.makeText(
                        this,
                        e.message ?: "Error desconocido",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun getDisplayName(uri: Uri): String? {
        var name: String? = null

        contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                name = cursor.getString(0)
            }
        }

        return name
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putStringArrayList(KEY_WHO, whoList)
        outState.putStringArrayList(KEY_BODY, bodyList)
        outState.putString(KEY_CURRENT_CHAT_ID, currentChatId)
    }

    override fun onStop() {
        // Con la burbuja flotante activa el renderer nativo sigue en uso: no lo soltamos.
        if (::avatarView.isInitialized && !FloatingAssistantService.isRunning) avatarView.nativeStop()
        super.onStop()
        // Guardamos la charla cada vez que salís de la app (no solo al rotar la
        // pantalla), para que siga ahí la próxima vez que la abras.
        saveCurrentChat()
        // La app ya no se ve: si la burbuja está activa, aparece ahora con el avatar.
        FloatingAssistantService.setAppForeground(false)
    }

    // El visor del avatar necesita que le avisemos cuando la app pasa a segundo plano o
    // vuelve, para soltar/recuperar la conexión con la GPU correctamente (si no, en
    // algunos teléfonos puede trabarse o gastar batería de más sin necesidad).
    override fun onPause() {
        super.onPause()
        if (::avatarView.isInitialized) {
            avatarView.onPause()
            avatarView.nativePause()
        }
    }

    override fun onResume() {
        super.onResume()
        MusicController.onEvent = { msg -> addMessage("Sonia", msg) }
        IdleDirector.start()
        IdleDirector.touch()
        // Primero se quita la burbuja (libera el renderer) y recién después dibuja esta pantalla.
        FloatingAssistantService.setAppForeground(true)
        // Fondo del avatar = color de la pantalla (la burbuja lo usa transparente).
        Live2DJniBridge.nativeSetClearColor(248f / 255f, 245f / 255f, 252f / 255f, 1f)
        if (::avatarView.isInitialized) {
            avatarView.onResume()
            avatarView.nativeStart()
        }
    }

    // --- Panel lateral: abrir/cerrar, y lista de chats guardados ---

    private fun toggleSidebar() {
        if (sidebarOpen) closeSidebar() else openSidebar()
    }

    private fun openSidebar() {
        refreshChatList()
        scrim.visibility = View.VISIBLE
        sidebar.visibility = View.VISIBLE
        sidebar.requestApplyInsets()
        sidebarOpen = true
    }

    private fun closeSidebar() {
        scrim.visibility = View.GONE
        sidebar.visibility = View.GONE
        sidebarOpen = false
    }

    private fun refreshChatList() {
        chatListContainer.removeAllViews()

        val chats = loadChatIndex().sortedByDescending { it.updatedAt }

        for (chat in chats) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val isCurrent = chat.id == currentChatId

            val label = TextView(this).apply {
                text = chat.title
                textSize = 14f
                setPadding(dp(8), dp(10), dp(8), dp(10))
                setTextColor(if (isCurrent) Color.rgb(92, 45, 135) else Color.rgb(50, 45, 55))
                if (isCurrent) {
                    background = GradientDrawable().apply {
                        setColor(Color.rgb(232, 218, 248))
                        setCornerRadius(dp(10).toFloat())
                    }
                }
                setOnClickListener {
                    if (chat.id != currentChatId) {
                        switchToChat(chat.id)
                    }
                    closeSidebar()
                }
            }
            row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))

            val deleteButton = Button(this).apply {
                text = "🗑"
                textSize = 12f
                setOnClickListener { confirmDeleteChat(chat.id, chat.title) }
            }
            row.addView(deleteButton)

            chatListContainer.addView(row)
        }
    }

    private fun confirmDeleteChat(chatId: String, title: String) {
        AlertDialog.Builder(this)
            .setTitle("¿Borrar \"$title\"?")
            .setPositiveButton("Borrar") { _, _ -> deleteChat(chatId) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun deleteChat(chatId: String) {
        chatFile(chatId).delete()
        val remaining = loadChatIndex().filter { it.id != chatId }
        saveChatIndex(remaining)

        if (chatId == currentChatId) {
            val next = remaining.maxByOrNull { it.updatedAt }
            if (next != null) {
                switchToChat(next.id)
            } else {
                startNewChat()
            }
        } else {
            refreshChatList()
        }
    }

    // --- Varios chats: crear, cambiar y migrar el historial guardado ---

    private fun startNewChat() {
        saveCurrentChat()

        currentChatId = System.currentTimeMillis().toString()
        whoList.clear()
        bodyList.clear()
        messages.removeAllViews()

        addMessage("Sonia", "¡Hola! Soy Sonia. 💜 ¿En qué te ayudo?")

        val index = loadChatIndex().toMutableList()
        index.add(ChatMeta(currentChatId, "Chat nuevo", System.currentTimeMillis()))
        saveChatIndex(index)

        modelPrefs().edit().putString(KEY_CURRENT_CHAT_ID, currentChatId).apply()
        refreshChatList()
        closeSidebar()
    }

    private fun switchToChat(chatId: String) {
        saveCurrentChat()

        currentChatId = chatId
        whoList.clear()
        bodyList.clear()
        messages.removeAllViews()

        if (!loadChatMessages(chatId)) {
            addMessage("Sonia", "¡Hola! Soy Sonia. 💜 ¿En qué te ayudo?")
        }

        modelPrefs().edit().putString(KEY_CURRENT_CHAT_ID, currentChatId).apply()
        refreshChatList()
    }

    private fun openLastOrNewChat() {
        val index = loadChatIndex()
        val lastId = modelPrefs().getString(KEY_CURRENT_CHAT_ID, null)
        val lastChat = index.firstOrNull { it.id == lastId } ?: index.maxByOrNull { it.updatedAt }

        if (lastChat != null) {
            currentChatId = lastChat.id
            if (!loadChatMessages(lastChat.id)) {
                addMessage("Sonia", "¡Hola! Soy Sonia. 💜 Cargá mi modelo para comenzar.")
            }
        } else {
            currentChatId = System.currentTimeMillis().toString()
            addMessage("Sonia", "¡Hola! Soy Sonia. 💜 Cargá mi modelo para comenzar.")
            val index2 = loadChatIndex().toMutableList()
            index2.add(ChatMeta(currentChatId, "Chat nuevo", System.currentTimeMillis()))
            saveChatIndex(index2)
        }

        modelPrefs().edit().putString(KEY_CURRENT_CHAT_ID, currentChatId).apply()
    }

    // Si la app venía de una versión vieja (antes de tener varios chats), convertimos
    // esa única conversación guardada en el primer chat de la lista, para no perderla.
    private fun migrateOldHistoryIfNeeded() {
        val oldFile = File(filesDir, "chat_history.txt")
        if (!oldFile.exists()) return
        if (loadChatIndex().isNotEmpty()) {
            oldFile.delete()
            return
        }

        val id = "migrado_" + System.currentTimeMillis().toString()
        oldFile.copyTo(chatFile(id), overwrite = true)
        oldFile.delete()

        val index = mutableListOf(ChatMeta(id, "Chat anterior", System.currentTimeMillis()))
        saveChatIndex(index)
        modelPrefs().edit().putString(KEY_CURRENT_CHAT_ID, id).apply()
    }

    // --- Burbujas de chat, alineadas como en un chat normal ---

    private fun addMessage(who: String, body: String) {
        whoList.add(who)
        bodyList.add(body)
        messages.addView(buildBubble(who, body))
        scrollToBottom()
    }

    private fun buildBubble(who: String, body: String): View {
        val isSonia = who == "Sonia"

        val bubble = TextView(this).apply {
            text = body
            textSize = 16f
            setTextColor(if (isSonia) Color.rgb(40, 35, 45) else Color.WHITE)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                setColor(if (isSonia) Color.rgb(232, 218, 248) else Color.rgb(123, 80, 173))
                setCornerRadius(dp(16).toFloat())
            }
        }

        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        // Sonia a la izquierda, vos a la derecha: así se distingue sin tener que
        // escribir "Vos:" o "Sonia:" adelante de cada mensaje.
        params.gravity = if (isSonia) Gravity.START else Gravity.END
        params.setMargins(0, dp(4), 0, dp(4))

        bubble.layoutParams = params
        return bubble
    }

    private fun showTyping() {
        if (typingBubble != null) return
        val bubble = buildBubble("Sonia", "Sonia está pensando...")
        typingBubble = bubble
        messages.addView(bubble)
        scrollToBottom()
        setAvatarState(AvatarState.THINKING)
        ActivityController.working = true
    }

    private fun hideTyping() {
        val bubble = typingBubble ?: return
        messages.removeView(bubble)
        typingBubble = null
        ActivityController.working = false
    }

    // (El enum AvatarState vive en Live2DView.kt, porque lo necesitan los dos
    // archivos: éste decide CUÁNDO cambiar de estado, y el otro decide CÓMO se mueve
    // el modelo Live2D en cada estado.)
    private fun setAvatarState(state: AvatarState) {
        if (::avatarView.isInitialized) avatarView.setState(state)
    }

    private fun scrollToBottom() {
        scroll.post {
            scroll.scrollTo(0, messages.bottom)
        }
    }

    // --- Voz: lee en voz alta las respuestas de Sonia (texto a voz de Android) ---

    private fun toggleVoice() {
        voiceEnabled = !voiceEnabled
        modelPrefs().edit().putBoolean(KEY_VOICE_ENABLED, voiceEnabled).apply()
        updateVoiceButtonText()
        if (!voiceEnabled) {
            tts?.stop()
        }
    }

    private fun updateVoiceButtonText() {
        voiceButton.text = if (voiceEnabled) "🔊 Voz: ON" else "🔇 Voz: OFF"
    }

    private fun speak(text: String) {
        if (!voiceEnabled || !ttsReady) {
            // Sin voz: igual mostramos la cara "hablando" un ratito y volvemos a la
            // cara neutral, para que el avatar acompañe aunque no haya audio.
            val estimatedMillis = (text.length * 45L).coerceIn(900L, 6000L)
            mainHandlerUi.postDelayed({ setAvatarState(AvatarState.NEUTRAL) }, estimatedMillis)
            return
        }
        val result = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sonia_respuesta")
        if (result != TextToSpeech.SUCCESS) {
            // Si el motor de voz no arrancó no habrá callback onDone: volvemos a neutral.
            setAvatarState(AvatarState.NEUTRAL)
        }
    }

    // El motor de voz de Android (normalmente "Google Text-to-Speech") puede traer
    // instaladas varias voces en español, de distinta calidad. Elegimos sola la de
    // mejor calidad disponible SIN necesitar internet (así la app se sigue
    // comportando offline), porque esa suele ser bastante menos "robótica" que la
    // voz básica que viene por defecto en muchos teléfonos.
    //
    // OJO: el sistema de Android no marca sus voces como "masculina" o "femenina"
    // (esa información no existe en su API pública), así que no podemos elegir una
    // voz femenina de forma 100% automática y segura. Lo que sí podemos asegurar es
    // la de mejor calidad; para elegir una puntualmente femenina, lo más confiable es
    // que la elijas vos mismo desde los Ajustes del teléfono (te explico abajo cómo).
    private fun pickBestSpanishVoice() {
        val engine = tts ?: return
        val voices = engine.voices ?: return

        val best = voices
            .filter { it.locale?.language == "es" && !it.isNetworkConnectionRequired }
            .maxByOrNull { it.quality }

        if (best != null) {
            engine.setVoice(best)
        }
    }

    // --- Envío de mensajes (desde el botón "Enviar" o desde el micrófono) ---

    private fun sendUserMessage(message: String) {
        IdleDirector.touch()
        addMessage("Vos", message)

        if (tryHandleAssistantCommand(message)) {
            return
        }

        if (!modelReady) {
            addMessage("Sonia", "Primero tenés que cargar mi modelo. 💜")
            return
        }

        sendButton.isEnabled = false
        micButton.isEnabled = false
        showTyping()

        SoniaAIEngine.sendMessage(message) { response ->
            hideTyping()
            addMessage("Sonia", response)
            EmotionController.react(response)
            setAvatarState(AvatarState.TALKING)
            speak(response)
            sendButton.isEnabled = true
            micButton.isEnabled = true
        }
    }

    // --- Micrófono: convierte lo que decís en texto, usando el reconocedor de voz
    // que ya trae Android (el mismo que usa el teclado de Google para dictar). No
    // agrega ninguna librería nueva ni pide permisos especiales: lo maneja la propia
    // app de reconocimiento de voz del teléfono. ---

    private fun openSpeechRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-AR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Hablale a Sonia...")
        }

        if (intent.resolveActivity(packageManager) == null) {
            Toast.makeText(
                this,
                "Tu teléfono no tiene instalada una app de reconocimiento de voz (por ejemplo, la app de Google).",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        startActivityForResult(intent, REQUEST_SPEECH)
    }

    // Órdenes tipo asistente (abrir apps, música, volumen, alarmas...). La lógica vive en
    // PhoneActions, que entiende sinónimos y se comparte con la burbuja flotante.
    private fun tryHandleAssistantCommand(message: String): Boolean {
        val reply = PhoneActions.handle(this, message) ?: return false
        addMessage("Sonia", reply)
        EmotionController.react(reply)
        return true
    }

    private fun onMusicFolderScanned(count: Int, announce: Boolean) {
        if (!::musicFolderButton.isInitialized) return
        musicFolderButton.text = if (count > 0) "📁 Carpeta de música ✓ ($count canciones)" else "📁 Carpeta de música"
        if (announce) {
            addMessage(
                "Sonia",
                if (count > 0) "Listo, encontré $count canciones. Pedime «poné música» o «poné <nombre o artista>». 🎵"
                else "No encontré audios en esa carpeta. Probá con otra."
            )
        }
    }

    private fun chooseMusicFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        try { startActivityForResult(intent, REQUEST_MUSIC_FOLDER) }
        catch (e: Exception) { Toast.makeText(this, "No pude abrir el selector de carpetas.", Toast.LENGTH_LONG).show() }
    }

    private fun chooseMusicFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, REQUEST_AUDIO)
    }

    private fun toggleFloatingAssistant() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) {
            val intent = Intent(
                android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "Permití que Sonia se muestre sobre otras aplicaciones y volvé acá.", Toast.LENGTH_LONG).show()
            return
        }
        if (!FloatingAssistantService.isRunning &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            // Android 13+: sin este permiso la notificación del servicio no se muestra.
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
            return
        }
        val intent = Intent(this, FloatingAssistantService::class.java)
        if (FloatingAssistantService.isRunning) {
            stopService(intent)
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
            else startService(intent)
            Toast.makeText(this, "Listo: Sonia aparece flotando cuando salís de la app.", Toast.LENGTH_LONG).show()
        }
        root.postDelayed({ updateFloatingButtonText() }, 400)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_NOTIFICATIONS) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                toggleFloatingAssistant()
            } else {
                Toast.makeText(this, "Sin permiso de notificaciones no puedo mostrar el avatar flotante.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun updateFloatingButtonText() {
        if (::floatingButton.isInitialized) {
            floatingButton.text = if (FloatingAssistantService.isRunning) {
                "✖ Ocultar avatar flotante"
            } else {
                "🫧 Activar avatar flotante"
            }
        }
    }

    private fun openGoogleSearch(query: String) {
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
        val intent = Intent(Intent.ACTION_VIEW, uri)

        try {
            startActivity(intent)
            addMessage("Sonia", "🔎 Abriendo Google para buscar: \"$query\"")
        } catch (e: Exception) {
            addMessage("Sonia", "No pude abrir el navegador para buscar eso. 💜")
        }
    }

    // --- Memoria / instrucciones fijas para la IA ---

    private fun openMemoryDialog() {
        val current = modelPrefs().getString(KEY_SYSTEM_INSTRUCTION, "") ?: ""

        val editText = EditText(this).apply {
            setText(current)
            hint = "Por ejemplo: Me llamo Pablo, respondeme siempre en español y de forma breve."
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }

        AlertDialog.Builder(this)
            .setTitle("🧠 Memoria / Instrucciones para Sonia")
            .setView(editText)
            .setPositiveButton("Guardar") { _, _ ->
                val text = editText.text.toString().trim()
                modelPrefs().edit().putString(KEY_SYSTEM_INSTRUCTION, text).apply()

                val appliedNow = SoniaAIEngine.updateSystemInstruction(text.ifEmpty { null })

                val info = if (!modelReady) {
                    "Instrucciones guardadas. Se van a usar la próxima vez que cargues el modelo."
                } else if (appliedNow) {
                    "Instrucciones guardadas y aplicadas ✓"
                } else {
                    "Instrucciones guardadas, pero no se pudieron aplicar todavía."
                }
                Toast.makeText(this, info, Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // --- Guardar y leer la charla del teléfono, un archivo por cada chat ---

    private fun chatsDir(): File {
        val dir = File(filesDir, "chats")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun chatFile(chatId: String): File = File(chatsDir(), "$chatId.txt")

    private fun indexFile(): File = File(chatsDir(), "index.txt")

    private data class ChatMeta(val id: String, val title: String, val updatedAt: Long)

    private fun loadChatIndex(): List<ChatMeta> {
        val file = indexFile()
        if (!file.exists()) return emptyList()

        val result = ArrayList<ChatMeta>()
        try {
            file.bufferedReader().useLines { lines ->
                for (line in lines) {
                    val parts = line.split("\u0001")
                    if (parts.size == 3) {
                        val updatedAt = parts[2].toLongOrNull() ?: 0L
                        result.add(ChatMeta(parts[0], parts[1], updatedAt))
                    }
                }
            }
        } catch (e: Exception) {
            // Si el índice está corrupto, mejor arrancar de una lista vacía que romper la app.
        }
        return result
    }

    private fun saveChatIndex(list: List<ChatMeta>) {
        try {
            indexFile().bufferedWriter().use { writer ->
                for (chat in list) {
                    writer.write(chat.id)
                    writer.write("\u0001")
                    writer.write(chat.title.replace("\n", " ").replace("\u0001", " "))
                    writer.write("\u0001")
                    writer.write(chat.updatedAt.toString())
                    writer.write("\n")
                }
            }
        } catch (e: Exception) {
            // Si no se pudo guardar el índice, la lista de chats puede no actualizarse,
            // pero no rompe la conversación actual.
        }
    }

    private fun deriveTitle(): String {
        val firstUserMessage = whoList.indices
            .firstOrNull { whoList[it] == "Vos" }
            ?.let { bodyList[it] }

        if (firstUserMessage.isNullOrBlank()) return "Chat nuevo"
        return if (firstUserMessage.length > 28) {
            firstUserMessage.take(28) + "…"
        } else {
            firstUserMessage
        }
    }

    private fun saveCurrentChat() {
        if (currentChatId.isEmpty()) return

        try {
            chatFile(currentChatId).bufferedWriter().use { writer ->
                for (i in whoList.indices) {
                    // Separador poco común para no confundirlo con texto normal.
                    writer.write(whoList[i].replace("\n", " "))
                    writer.write("\u0001")
                    writer.write(bodyList[i].replace("\n", " "))
                    writer.write("\n")
                }
            }
        } catch (e: Exception) {
            // Si no se pudo guardar, no pasa nada grave: la próxima vez arranca de cero.
        }

        val index = loadChatIndex().toMutableList()
        val existing = index.indexOfFirst { it.id == currentChatId }
        val newMeta = ChatMeta(currentChatId, deriveTitle(), System.currentTimeMillis())

        if (existing >= 0) {
            index[existing] = newMeta
        } else {
            index.add(newMeta)
        }
        saveChatIndex(index)
    }

    private fun loadChatMessages(chatId: String): Boolean {
        val file = chatFile(chatId)
        if (!file.exists()) return false

        try {
            file.bufferedReader().useLines { lines ->
                for (line in lines) {
                    val parts = line.split("\u0001", limit = 2)
                    if (parts.size == 2) {
                        addMessage(parts[0], parts[1])
                    }
                }
            }
        } catch (e: Exception) {
            return false
        }

        return whoList.isNotEmpty()
    }

    private fun modelPrefs() = getSharedPreferences("sonia_prefs", MODE_PRIVATE)

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    @Suppress("DEPRECATION")
    private fun systemInsets(insets: WindowInsets): IntArray {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bars = insets.getInsets(
                WindowInsets.Type.systemBars() or
                    WindowInsets.Type.displayCutout() or
                    WindowInsets.Type.ime()
            )

            intArrayOf(
                bars.left,
                bars.top,
                bars.right,
                bars.bottom
            )
        } else {
            intArrayOf(
                insets.systemWindowInsetLeft,
                insets.systemWindowInsetTop,
                insets.systemWindowInsetRight,
                insets.systemWindowInsetBottom
            )
        }
    }

    override fun onDestroy() {
        if (::avatarView.isInitialized && !FloatingAssistantService.isRunning) avatarView.nativeDestroy()
        super.onDestroy()
        tts?.stop()
        tts?.shutdown()
        MusicController.onEvent = null
        if (!FloatingAssistantService.isRunning) MusicController.stop()
        ioExecutor.shutdownNow()
        // Ya NO cerramos SoniaAIEngine acá: es un "object" compartido por toda la app,
        // y queremos justamente que el modelo se quede cargado en memoria aunque esta
        // pantalla se destruya (por ejemplo, al rotar, o al salir y volver a entrar).
    }

    private companion object {
        const val KEY_WHO = "chat_who"
        const val KEY_BODY = "chat_body"
        const val KEY_MODEL_PATH = "model_path"
        const val KEY_BACKEND_PREF = "backend_pref"
        const val KEY_SYSTEM_INSTRUCTION = "system_instruction"
        const val KEY_VOICE_ENABLED = "voice_enabled"
        const val KEY_CURRENT_CHAT_ID = "current_chat_id"
        const val REQUEST_MODEL = 1001
        const val REQUEST_SPEECH = 1002
        const val REQUEST_AUDIO = 1003
        const val REQUEST_NOTIFICATIONS = 1004
        const val REQUEST_MUSIC_FOLDER = 1005
        const val KEY_AVATAR_SCALE = "avatar_scale"
        const val ACTION_START_VOICE = "com.sonia.ai.START_VOICE"
        // Tamaño del avatar dentro de la app (antes 170x210) y con el teclado abierto.
        const val AVATAR_W_DP = 260
        const val AVATAR_H_DP = 330
        const val AVATAR_COMPACT_W_DP = 100
        const val AVATAR_COMPACT_H_DP = 125
    }
}
