package com.sonia.ai

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Acciones reales de Sonia en el teléfono. Entiende pedidos "con sus palabras" (sinónimos,
 * voseo, relleno tipo "por favor / podés / quiero que") sin depender de frases fijas.
 *
 * [handle] devuelve lo que Sonia contesta si el mensaje era una orden que pudo ejecutar, o
 * null si no lo era (entonces el mensaje va a la IA como conversación normal).
 * Es compartido por la pantalla principal y por la burbuja flotante.
 */
object PhoneActions {

    private var torchOn = false

    // ------------------------------------------------------------------ vocabulario

    private val MUSIC_WORDS = setOf(
        "musica", "cancion", "canciones", "tema", "temas", "audio", "audios", "rola", "rolas",
        "melodia", "playlist", "pista", "disco", "album"
    )
    private val GENERIC_MUSIC = setOf(
        "la", "el", "los", "las", "de", "del", "un", "una", "unos", "unas", "al", "algo", "que",
        "cancion", "canciones", "tema", "temas", "musica", "audio", "audios", "disco", "lista",
        "playlist", "pista", "carpeta", "mi", "mis", "por", "favor", "y", "con", "en", "a", "me",
        "te", "rola", "rolas", "melodia", "buena", "linda", "copada", "para", "escuchar", "yo",
        "cualquier", "cualquiera", "algun", "alguna", "azar", "aleatoria", "aleatorio", "random",
        "shuffle", "mezcla", "mezclada", "sorpresa", "telefono", "celular"
    )
    private val RANDOM_WORDS = setOf(
        "azar", "aleatoria", "aleatorio", "random", "shuffle", "mezcla", "mezclada", "cualquiera",
        "sorpresa", "sorprendeme"
    )
    private val STRICT_PLAY = setOf(
        "reproduce", "reproducir", "reproduci", "reproducime", "reproduzca", "escucha", "escuchar",
        "escuchame", "play"
    )
    private val LOOSE_PLAY = setOf(
        "pone", "pon", "poner", "ponme", "poneme", "ponele", "pones", "ponga", "toca", "tocame",
        "tocar", "mete", "metele", "suena", "sonar", "dale"
    )
    private val RESUME_WORDS = setOf(
        "continua", "continuar", "segui", "seguir", "sigue", "reanuda", "reanudar", "retoma",
        "retomar", "resume", "continuala", "seguila"
    )
    private val PAUSE_ONLY = setOf("pausa", "pausar", "pausala", "pausalo")
    private val STOP_WORDS = setOf(
        "para", "parar", "paralo", "paramela", "stop", "frena", "frenar", "frenala", "frenalo",
        "deten", "detener", "detenela", "detenelo", "detene", "apaga", "apagar", "apagala",
        "apagalo", "corta", "cortar", "cortala", "cortalo", "cerra", "cerrar"
    )
    private val NEXT_WORDS = setOf(
        "siguiente", "proxima", "proximo", "saltea", "saltear", "saltar", "salta", "skip", "next",
        "otra", "otro", "adelanta", "adelantar", "pasa", "pasala", "pasalo", "cambia", "cambiala",
        "cambialo", "cambiar", "pasar"
    )
    private val PREV_WORDS = setOf(
        "anterior", "previa", "previo", "atras", "retrocede", "retroceder", "volve", "vuelve",
        "volver", "back"
    )
    private val OPEN_STRICT = setOf(
        "abri", "abre", "abrir", "abrime", "abrinos", "abra", "lanza", "lanzar", "lanzame",
        "inicia", "iniciar", "iniciame", "ejecuta", "ejecutar", "ejecutame", "arranca", "arrancar"
    )
    private val OPEN_LOOSE = setOf("anda", "andate", "entra", "entrar", "mostrame", "muestrame")
    private val SEARCH_VERBS = setOf(
        "busca", "buscame", "buscar", "buscas", "busques", "googlea", "googleame", "googlear",
        "investiga", "investigame", "investigar", "averigua", "averiguame", "averiguar", "fijate"
    )
    private val UP_WORDS = setOf(
        "subi", "sube", "subir", "subile", "subime", "sube", "aumenta", "aumentar", "aumentale",
        "levanta", "levantale", "mas", "maximo", "alto", "fuerte"
    )
    private val DOWN_WORDS = setOf(
        "baja", "bajar", "bajale", "bajame", "reduci", "reduce", "reducir", "disminui",
        "disminuir", "menos", "bajo", "despacio", "suave", "minimo"
    )
    private val MUTE_WORDS = setOf(
        "silencia", "silenciar", "silenciame", "silenciala", "mutea", "mutear", "mute", "silencio",
        "callala"
    )
    private val UNMUTE_WORDS = setOf("desmutea", "desmutear", "desilencia", "desilenciar")

    private val NUMWORDS = mapOf(
        "un" to 1, "uno" to 1, "una" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5,
        "seis" to 6, "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11,
        "doce" to 12, "quince" to 15, "veinte" to 20, "treinta" to 30, "cuarenta" to 40,
        "cincuenta" to 50, "sesenta" to 60
    )
    private val NUM_ALT = NUMWORDS.keys.joinToString("|")

    private val APP_ALIASES: Map<String, List<String>> = mapOf(
        "galeria" to listOf("fotos", "photos", "galeria", "gallery"),
        "fotos" to listOf("fotos", "photos", "galeria", "gallery"),
        "camara" to listOf("camara", "camera"),
        "mensajes" to listOf("mensajes", "messages", "sms"),
        "mensaje" to listOf("mensajes", "messages", "sms"),
        "calculadora" to listOf("calculadora", "calculator"),
        "reloj" to listOf("reloj", "clock"),
        "ajustes" to listOf("ajustes", "configuracion", "settings"),
        "configuracion" to listOf("ajustes", "configuracion", "settings"),
        "config" to listOf("ajustes", "configuracion", "settings"),
        "contactos" to listOf("contactos", "contacts"),
        "agenda" to listOf("contactos", "contacts", "calendario", "calendar"),
        "telefono" to listOf("telefono", "phone", "llamadas"),
        "llamadas" to listOf("telefono", "phone", "llamadas"),
        "navegador" to listOf("chrome", "navegador", "browser", "internet", "firefox"),
        "internet" to listOf("chrome", "navegador", "browser", "internet", "firefox"),
        "mapas" to listOf("maps", "mapas"),
        "mapa" to listOf("maps", "mapas"),
        "correo" to listOf("gmail", "correo", "email", "outlook"),
        "mail" to listOf("gmail", "correo", "email", "outlook"),
        "email" to listOf("gmail", "correo", "email", "outlook"),
        "calendario" to listOf("calendario", "calendar"),
        "musica" to listOf("musica", "music", "spotify"),
        "archivos" to listOf("archivos", "files"),
        "tienda" to listOf("play store", "tienda"),
        "play store" to listOf("play store", "tienda"),
        "notas" to listOf("notas", "keep", "notes"),
        "whats" to listOf("whatsapp"),
        "wasap" to listOf("whatsapp"),
        "guasap" to listOf("whatsapp"),
        "wsp" to listOf("whatsapp"),
        "insta" to listOf("instagram"),
        "face" to listOf("facebook"),
        "tik tok" to listOf("tiktok"),
        "yutub" to listOf("youtube"),
        "gugle" to listOf("google", "chrome")
    )

    // ------------------------------------------------------------------ entrada

    fun handle(ctx: Context, raw: String): String? {
        val n = clean(raw)
        if (n.isEmpty()) return null
        val t = n.split(' ')

        return emotion(n, t)
            ?: timeAndDate(n, t)
            ?: battery(ctx, n, t)
            ?: flashlight(ctx, n, t)
            ?: timerAndAlarm(ctx, n, t)
            ?: volume(ctx, n, t)
            ?: musicControl(n, t)
            ?: youtube(ctx, n, t)
            ?: musicPlay(n, t)
            ?: maps(ctx, n)
            ?: call(ctx, n, t)
            ?: settingsPanels(ctx, n, t)
            ?: webSearch(ctx, n)
            ?: openApp(ctx, n, t)
    }

    /** Normaliza y le saca el relleno de cortesía del principio/final. */
    private fun clean(raw: String): String {
        var s = MusicController.normalize(raw)
        s = s.replace("wi fi", "wifi").replace("tik tok", "tiktok")
        val lead = Regex("^(hola|hey|ey|che|sonia|dale|bueno|oye|ahora|entonces|porfa|por favor|a ver|ok)\\s+")
        val ask = Regex(
            "^(me gustaria que|me gustaria|tengo ganas de|quiero que|quisiera que|necesito que|te pido que|" +
                "podes|podrias|puedes|podria|puede|sabes|queria|quiero|necesito|me)\\s+"
        )
        repeat(3) {
            s = s.replace(lead, "").replace(ask, "")
        }
        s = s.replace(Regex("\\s+(por favor|porfa|gracias)$"), "")
        return s.trim()
    }

    private fun hasAny(t: List<String>, vararg w: String) = w.any { it in t }
    private fun hasPhrase(n: String, vararg p: String) = p.any { " $n ".contains(" $it ") }
    private fun isMusicWord(t: List<String>) = t.any { it in MUSIC_WORDS }

    private fun go(ctx: Context, intent: Intent): Boolean = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (_: ActivityNotFoundException) {
        false
    } catch (_: SecurityException) {
        false
    } catch (_: Exception) {
        false
    }

    // ------------------------------------------------------------------ expresiones de la cara

    private fun emotion(n: String, t: List<String>): String? {
        if (t.size > 8) return null
        if (hasAny(t, "automatico", "automatica", "auto") && hasAny(t, "expresion", "expresiones", "cara", "emocion", "emociones", "gestos", "modo")) {
            EmotionController.setAuto()
            return "Listo, vuelvo al modo automático: reacciono según lo que hablemos. 🎭"
        }
        val verbs = setOf(
            "pone", "pon", "ponete", "ponte", "ponga", "poneme", "estate", "hace", "hacete", "haz",
            "mostra", "mostrame", "muestrame", "actua", "actuame", "fingi", "simula", "mostrate", "demostra"
        )
        val marker = hasAny(t, "cara", "carita", "expresion", "emocion", "actitud", "gesto", "modo", "mirada") ||
            t[0] in setOf("ponete", "ponte", "estate", "hacete", "mostrate", "actua", "actuame", "fingi", "simula")
        if (t[0] !in verbs || !marker) return null
        val e = t.firstNotNullOfOrNull { EmotionController.fromWord(it) } ?: return null
        EmotionController.setManual(e)
        return when (e) {
            AvatarEmotion.NEUTRAL -> "Cara neutral. 😐 (Decime «modo automático» para que reaccione sola.)"
            AvatarEmotion.HAPPY -> "¡Estoy feliz! 😊"
            AvatarEmotion.ANGRY -> "Grrr, estoy enojada. 😠"
            AvatarEmotion.SAD -> "Estoy triste... 😢"
            AvatarEmotion.SURPRISED -> "¡Oh! ¿En serio? 😮"
            AvatarEmotion.PENSIVE -> "Hmm, déjame pensar... 🤔"
            AvatarEmotion.SHY -> "Ay, me da vergüenza... 😳"
            AvatarEmotion.WINK -> "😉"
            AvatarEmotion.SLEEPY -> "Uf, tengo sueño... 😴"
            AvatarEmotion.LAUGH -> "¡Jajaja! 😂"
            AvatarEmotion.SMUG -> "Obvio que sí. 😏"
            AvatarEmotion.BORED -> "Qué aburrido todo... 😒"
        }
    }

    // ------------------------------------------------------------------ hora y fecha

    private fun timeAndDate(n: String, t: List<String>): String? {
        if (hasPhrase(n, "a que hora", "a la hora de")) return null
        val asksTime = hasPhrase(
            n, "que hora es", "que horas son", "la hora", "hora actual", "que hora tenes",
            "hora es", "decime la hora"
        ) || t == listOf("hora")
        if (asksTime && t.size <= 7) {
            val now = SimpleDateFormat("HH:mm", Locale("es", "AR")).format(Date())
            return "Son las $now."
        }
        if (hasPhrase(
                n, "que dia es", "que dia es hoy", "que fecha es", "que fecha", "fecha de hoy",
                "a cuanto estamos", "que dia estamos", "dia de hoy", "en que fecha estamos"
            ) && t.size <= 8
        ) {
            val f = SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy", Locale("es", "AR")).format(Date())
            return "Hoy es $f."
        }
        return null
    }

    // ------------------------------------------------------------------ batería

    private fun battery(ctx: Context, n: String, t: List<String>): String? {
        if (!hasAny(t, "bateria", "pila")) return null
        val asks = hasAny(t, "cuanta", "cuanto", "nivel", "porcentaje", "queda", "tengo", "estado", "como") ||
            hasPhrase(n, "que tal la bateria")
        if (!asks) return null
        return try {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            if (pct in 0..100) "Tenés $pct% de batería. 🔋" else null
        } catch (_: Exception) {
            null
        }
    }

    // ------------------------------------------------------------------ linterna

    private fun flashlight(ctx: Context, n: String, t: List<String>): String? {
        val mentions = hasAny(t, "linterna", "linternita", "flash") ||
            hasPhrase(n, "luz del celular", "luz del telefono", "luz del cel")
        if (!mentions) return null
        val off = hasAny(
            t, "apaga", "apagar", "apagala", "apagalo", "desactiva", "desactivar", "saca", "sacala",
            "cerra", "corta"
        )
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "Este teléfono no tiene flash para usar de linterna."
            cm.setTorchMode(id, !off)
            torchOn = !off
            if (off) "Apagué la linterna. 🔦" else "Prendí la linterna. 🔦"
        } catch (_: Exception) {
            "No pude manejar la linterna ahora (puede estar en uso por la cámara)."
        }
    }

    // ------------------------------------------------------------------ temporizador y alarma

    private fun timerAndAlarm(ctx: Context, n: String, t: List<String>): String? {
        val timerWord = hasAny(t, "temporizador", "timer", "cronometro") || hasPhrase(n, "cuenta regresiva")
        val remindWord = hasAny(t, "avisame", "recordame", "despertame", "desperta")
        val alarmWord = hasAny(t, "alarma", "alarmas", "despertador")

        if (timerWord || remindWord) {
            val secs = parseDuration(n, requireEn = !timerWord)
            if (secs != null && secs > 0) {
                val i = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(AlarmClock.EXTRA_LENGTH, secs)
                    putExtra(AlarmClock.EXTRA_MESSAGE, "Sonia")
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                }
                return if (go(ctx, i)) "Listo, te aviso en ${describeDuration(secs)}. ⏱️"
                else "No encontré una app de reloj para poner el temporizador."
            }
        }

        if (alarmWord || (remindWord && hasAny(t, "despertame", "desperta"))) {
            val cancel = hasAny(t, "cancela", "cancelar", "borra", "borrar", "elimina", "eliminar", "apaga", "desactiva")
            val clock = if (cancel) null else parseClock(n)
            if (clock != null) {
                val (h, m) = clock
                val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_HOUR, h)
                    putExtra(AlarmClock.EXTRA_MINUTES, m)
                    putExtra(AlarmClock.EXTRA_MESSAGE, "Sonia")
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                }
                val hh = h.toString().padStart(2, '0')
                val mm = m.toString().padStart(2, '0')
                return if (go(ctx, i)) "Listo, alarma puesta para las $hh:$mm. ⏰"
                else "No encontré una app de reloj para poner la alarma."
            }
            val showed = go(ctx, Intent(AlarmClock.ACTION_SHOW_ALARMS))
            return if (showed) {
                if (cancel) "Te abro tus alarmas para que la desactives."
                else "Te abro las alarmas. Si querés que la ponga yo, decime la hora: «alarma a las 7:30»."
            } else "No encontré una app de reloj."
        }
        return null
    }

    private fun parseDuration(n: String, requireEn: Boolean): Int? {
        if (hasPhrase(n, "media hora")) return 1800
        val prefix = if (requireEn) "(?:^| )en " else "(?:^| )(?:en |de |por )?"
        val re = Regex("$prefix(\\d+|$NUM_ALT) (segundos?|seg|minutos?|min|horas?|hs|h)(?: |$)")
        val m = re.find(n) ?: return null
        val raw = m.groupValues[1]
        val value = raw.toIntOrNull() ?: NUMWORDS[raw] ?: return null
        val unit = m.groupValues[2]
        return when {
            unit.startsWith("seg") -> value
            unit.startsWith("min") -> value * 60
            else -> value * 3600
        }
    }

    private fun describeDuration(secs: Int): String = when {
        secs % 3600 == 0 -> "${secs / 3600} h"
        secs >= 3600 -> "${secs / 3600} h ${(secs % 3600) / 60} min"
        secs % 60 == 0 -> "${secs / 60} min"
        secs > 60 -> "${secs / 60} min ${secs % 60} s"
        else -> "$secs s"
    }

    private fun parseClock(raw: String): Pair<Int, Int>? {
        val n = raw.replace(Regex("\\b(las|la) ($NUM_ALT)\\b")) {
            "${it.groupValues[1]} ${NUMWORDS[it.groupValues[2]]}"
        }
        val m = Regex("\\b(\\d{1,2})\\b(?: (\\d{2})\\b)?").find(n) ?: return null
        var h = m.groupValues[1].toInt()
        var min = m.groupValues[2].ifEmpty { "0" }.toInt()
        val rest = n.substring(m.range.last + 1)
        when {
            rest.contains(" y media") -> min = 30
            rest.contains(" y cuarto") -> min = 15
            rest.contains(" menos cuarto") -> { h -= 1; min = 45 }
        }
        val pm = n.contains("de la tarde") || n.contains("de la noche") || Regex("\\bpm\\b").containsMatchIn(n)
        val am = n.contains("de la manana") || n.contains("de la madrugada") || Regex("\\bam\\b").containsMatchIn(n)
        if (pm && h < 12) h += 12
        if (am && h == 12) h = 0
        if (h !in 0..23 || min !in 0..59) return null
        return h to min
    }

    // ------------------------------------------------------------------ volumen

    private fun volume(ctx: Context, n: String, t: List<String>): String? {
        val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val volWord = hasAny(t, "volumen", "sonido")
        val flags = AudioManager.FLAG_SHOW_UI
        val stream = AudioManager.STREAM_MUSIC

        if (hasAny(t, *UNMUTE_WORDS.toTypedArray()) ||
            hasPhrase(n, "saca el silencio", "quita el silencio", "activa el sonido", "saca el mute", "quita el mute")
        ) {
            audio.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, flags)
            return "Listo, volvió el sonido. 🔊"
        }

        var action: String? = null
        if (volWord) {
            val num = Regex("\\b(\\d{1,3})\\b").find(n)?.groupValues?.get(1)?.toIntOrNull()
            val max = audio.getStreamMaxVolume(stream)
            when {
                hasAny(t, *MUTE_WORDS.toTypedArray()) || hasPhrase(n, "sin sonido") -> action = "mute"
                hasPhrase(n, "al maximo", "a tope", "al palo", "maximo") && !hasAny(t, "minimo") -> {
                    audio.setStreamVolume(stream, max, flags); return "Volumen multimedia al máximo. 🔊"
                }
                hasPhrase(n, "al minimo", "minimo") -> {
                    audio.setStreamVolume(stream, 1.coerceAtMost(max), flags); return "Volumen al mínimo."
                }
                num != null && num in 0..100 -> {
                    audio.setStreamVolume(stream, Math.round(max * num / 100f), flags)
                    return "Dejé el volumen multimedia al $num%. 🔊"
                }
                hasAny(t, *DOWN_WORDS.toTypedArray()) -> action = "down"
                hasAny(t, *UP_WORDS.toTypedArray()) -> action = "up"
            }
        } else {
            action = when {
                hasPhrase(n, "mas fuerte", "mas alto", "mas volumen") -> "up"
                hasPhrase(n, "mas bajo", "mas despacio", "mas suave", "menos volumen") -> "down"
                t.size <= 2 && t[0] in MUTE_WORDS -> "mute"
                else -> null
            }
        }
        action ?: return null

        val steps = if (hasAny(t, "poco", "poquito", "toque")) 1 else 2
        return when (action) {
            "mute" -> {
                audio.adjustStreamVolume(stream, AudioManager.ADJUST_MUTE, flags)
                "Silencié el volumen multimedia. 🔇"
            }
            "up" -> {
                repeat(steps) { audio.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, flags) }
                "Subí el volumen (${percent(audio)}%). 🔊"
            }
            else -> {
                repeat(steps) { audio.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, flags) }
                "Bajé el volumen (${percent(audio)}%). 🔉"
            }
        }
    }

    private fun percent(audio: AudioManager): Int {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return Math.round(audio.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f / max)
    }

    // ------------------------------------------------------------------ música (control)

    private fun musicControl(n: String, t: List<String>): String? {
        val musicWord = isMusicWord(t)
        val small = t.size <= 3 && MusicController.hasPlayer

        if (hasPhrase(n, "que suena", "que esta sonando", "que estoy escuchando", "que cancion es esta", "que tema es este")) {
            return MusicController.nowPlayingTitle()?.let { "Suena «$it». 🎶" } ?: "No hay música sonando ahora."
        }
        if (t.size == 1 && t[0] in PAUSE_ONLY) return MusicController.pause()
        if (t.size == 1 && t[0] in STOP_WORDS) return MusicController.stop()
        if (t[0] in PAUSE_ONLY && musicWord) return MusicController.pause()
        if (t.any { it in STOP_WORDS } && musicWord && t[0] !in LOOSE_PLAY && t[0] !in STRICT_PLAY) {
            return MusicController.stop()
        }
        if (hasPhrase(n, "dale play", "dale al play")) return MusicController.resume()
        if (t[0] in RESUME_WORDS && (t.size == 1 || musicWord || MusicController.hasPlayer)) {
            return MusicController.resume()
        }
        if (t.any { it in NEXT_WORDS } && (musicWord || small) && t[0] !in STRICT_PLAY) {
            // "poné otra canción" también cuenta como pasar a la siguiente.
            if (musicWord || t.size <= 3) {
                val specific = t.filter { it !in NEXT_WORDS && it !in GENERIC_MUSIC && it !in LOOSE_PLAY }
                if (specific.isEmpty()) return MusicController.next()
            }
        }
        if (t.any { it in PREV_WORDS } && (musicWord || small)) {
            val specific = t.filter { it !in PREV_WORDS && it !in GENERIC_MUSIC && it !in LOOSE_PLAY }
            if (specific.isEmpty()) return MusicController.previous()
        }
        return null
    }

    // ------------------------------------------------------------------ música (reproducir)

    private fun musicPlay(n: String, t: List<String>): String? {
        val verb = t[0]
        val musicWord = isMusicWord(t)
        val webWords = hasPhrase(n, "en google", "en internet", "en la web", "en youtube")
        val searchAsPlay = verb in SEARCH_VERBS && musicWord && !webWords
        if (verb !in STRICT_PLAY && verb !in LOOSE_PLAY && !searchAsPlay) return null

        val rest = t.drop(1)
        val restStr = rest.joinToString(" ")

        if (rest.isEmpty()) {
            return if (verb in STRICT_PLAY) MusicController.resume() else null
        }

        val wantsRandom = rest.any { it in RANDOM_WORDS }
        val generic = rest.all { it in GENERIC_MUSIC }
        if (generic || wantsRandom) {
            // "poné algo" sin más puede ser cualquier cosa: solo lo tomamos como música si
            // hay una palabra de música, una biblioteca cargada o un verbo claro de reproducir.
            if (!(musicWord || verb in STRICT_PLAY || MusicController.hasLibrary)) return null
            if (!musicWord && verb !in STRICT_PLAY && !wantsRandom) return null
            return MusicController.playAny(wantsRandom)
        }

        if (MusicController.hasLibrary) {
            return if (MusicController.findBest(restStr) != null) {
                MusicController.playQuery(restStr)
            } else if (musicWord || verb in STRICT_PLAY) {
                MusicController.playQuery(restStr) // devuelve el "no encontré..."
            } else null
        }
        return if (musicWord) MusicController.playAny(false) else null
    }

    // ------------------------------------------------------------------ YouTube

    private fun youtube(ctx: Context, n: String, t: List<String>): String? {
        if ("youtube" !in t) return null
        val verbs = SEARCH_VERBS + LOOSE_PLAY + STRICT_PLAY + setOf("ver", "mira", "mirar", "mostrame")
        if (t[0] !in verbs) return null
        var q = n.replace(Regex("^\\S+ "), "")
        q = q.replace(Regex("\\b(en|de|por|con|desde) youtube\\b"), " ").replace(Regex("\\byoutube\\b"), " ")
        q = q.replace(Regex("\\b(un video de|videos de|el video de|un video|videos|video)\\b"), " ")
            .replace(Regex("\\s+"), " ").trim()
        if (q.isEmpty()) return null
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
        return if (go(ctx, i)) "Busco «$q» en YouTube. ▶️" else "No pude abrir YouTube."
    }

    // ------------------------------------------------------------------ mapas

    private fun maps(ctx: Context, n: String): String? {
        val re = Regex(
            "^(?:como llego a|como llegar a|como voy a|llevame a|llevame hasta|navega a|navegar a|navegame a|" +
                "ruta a|ruta hasta|indicaciones para llegar a|donde queda|donde esta|mapa de|abre el mapa de|" +
                "mostrame el mapa de|mostrame en el mapa) (.+)$"
        )
        val q = re.find(n)?.groupValues?.get(1)?.trim() ?: return null
        if (q.split(' ').size > 8) return null
        if (q.startsWith("mi ") || q.startsWith("mis ")) return null
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q)))
        return if (go(ctx, i)) "Te muestro «$q» en el mapa. 🗺️" else "No encontré una app de mapas."
    }

    // ------------------------------------------------------------------ llamar

    private fun call(ctx: Context, n: String, t: List<String>): String? {
        if (t[0] !in setOf("llama", "llamar", "llamame", "marca", "marcar", "telefonea", "llamalo", "llamala")) return null
        val digits = n.filter { it.isDigit() }
        if (digits.length >= 3) {
            val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits"))
            return if (go(ctx, i)) "Te dejo el número $digits en el teléfono, tocá llamar. 📞"
            else "No pude abrir el teléfono."
        }
        return "Todavía no puedo ver tus contactos. Decime el número y te lo dejo marcado: «llamá al 11 2345 6789»."
    }

    // ------------------------------------------------------------------ pantallas de ajustes

    private fun settingsPanels(ctx: Context, n: String, t: List<String>): String? {
        val verbs = setOf(
            "prende", "prender", "prendelo", "enciende", "encende", "encender", "activa", "activar",
            "apaga", "apagar", "desactiva", "desactivar", "abri", "abre", "abrir", "configura",
            "configurar", "cambia", "cambiar", "ajusta", "ajustar", "subi", "sube", "baja", "bajar",
            "conecta", "conectar", "desconecta", "desconectar", "mostrame", "pone", "pon"
        )
        if (t.none { it in verbs }) return null
        val opening = hasAny(t, "abri", "abre", "abrir", "mostrame", "configura", "configurar")

        data class Panel(val action: String, val label: String)
        val panel: Panel = when {
            hasAny(t, "wifi") -> Panel(Settings.ACTION_WIFI_SETTINGS, "el WiFi")
            hasAny(t, "bluetooth") -> Panel(Settings.ACTION_BLUETOOTH_SETTINGS, "el Bluetooth")
            hasPhrase(n, "modo avion", "datos moviles", "datos del celular", "red movil") ->
                Panel(Settings.ACTION_WIRELESS_SETTINGS, "las conexiones")
            hasAny(t, "brillo") -> Panel(Settings.ACTION_DISPLAY_SETTINGS, "el brillo de pantalla")
            hasAny(t, "ubicacion", "gps") -> Panel(Settings.ACTION_LOCATION_SOURCE_SETTINGS, "la ubicación")
            hasPhrase(n, "ahorro de bateria", "ahorro de energia", "modo ahorro") ->
                Panel(Settings.ACTION_BATTERY_SAVER_SETTINGS, "el ahorro de batería")
            hasPhrase(n, "no molestar") -> Panel(Settings.ACTION_SOUND_SETTINGS, "los sonidos")
            else -> return null
        }
        val ok = go(ctx, Intent(panel.action))
        if (!ok) return "No pude abrir los ajustes de ${panel.label}."
        return if (opening) "Te abro los ajustes de ${panel.label}. ⚙️"
        else "Android no me deja cambiar ${panel.label} directamente, así que te abro la pantalla para que lo hagas con un toque. ⚙️"
    }

    // ------------------------------------------------------------------ búsqueda web

    private fun webSearch(ctx: Context, n: String): String? {
        val m = Regex("^(?:abri|abre|abrir) (?:google|el navegador|chrome|internet) y (?:busca|buscame|buscar) (.+)$").find(n)
            ?: Regex("^(?:${SEARCH_VERBS.joinToString("|")}) (.+)$").find(n)
            ?: return null
        var q = m.groupValues[1]
        q = q.replace(Regex("^(en|por) (google|internet|la web|el navegador|chrome) "), "")
            .replace(Regex(" (en|por) (google|internet|la web|el navegador|chrome)$"), "")
            .replace(Regex("\\s+"), " ").trim()
        if (q.isEmpty()) return null
        val i = Intent(Intent.ACTION_WEB_SEARCH).apply { putExtra(SearchManager.QUERY, q) }
        val ok = go(ctx, i) || go(
            ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
        )
        return if (ok) "Buscando «$q» en Google. 🔎" else "No pude abrir el navegador."
    }

    // ------------------------------------------------------------------ abrir apps

    private class AppEntry(val label: String, val norm: String, val pkg: String, val cls: String)

    private fun installedApps(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return try {
            pm.queryIntentActivities(launcher, 0).map {
                val label = it.loadLabel(pm).toString()
                AppEntry(label, MusicController.normalize(label), it.activityInfo.packageName, it.activityInfo.name)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun bestApp(apps: List<AppEntry>, keywords: List<String>, minScore: Int): Pair<AppEntry, Int>? {
        var best: AppEntry? = null
        var bestScore = 0
        for (a in apps) {
            var s = 0
            for (k in keywords) {
                if (k.isEmpty()) continue
                val score = when {
                    a.norm == k -> 3
                    a.norm.startsWith(k) && k.length >= 3 -> 2
                    k.length >= 3 && a.norm.contains(k) -> 1
                    else -> 0
                }
                if (score > s) s = score
            }
            if (s > bestScore || (s == bestScore && s > 0 && best != null && a.norm.length < best.norm.length)) {
                best = a
                bestScore = s
            }
        }
        return if (best != null && bestScore >= minScore) best to bestScore else null
    }

    private fun launch(ctx: Context, app: AppEntry): Boolean {
        val i = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setClassName(app.pkg, app.cls)
        }
        return go(ctx, i)
    }

    private fun openApp(ctx: Context, n: String, t: List<String>): String? {
        val verb = t[0]
        val strict = verb in OPEN_STRICT
        val loose = verb in OPEN_LOOSE

        if (!strict && !loose) {
            // Mensaje de una o dos palabras que es justo el nombre de una app ("whatsapp").
            if (t.size > 2 || verb in GENERIC_MUSIC) return null
            val apps = installedApps(ctx)
            val hit = bestApp(apps, listOf(n), 3) ?: return null
            return if (launch(ctx, hit.first)) "Abriendo ${hit.first.label}. 💜" else null
        }

        val ignore = setOf(
            "a", "al", "la", "el", "los", "las", "en", "mi", "mis", "app", "apps", "aplicacion",
            "aplicaciones", "programa", "de", "del", "pantalla", "me", "un", "una"
        )
        val rest = t.drop(1).dropWhile { it in ignore }
        val query = rest.joinToString(" ")
        if (query.isEmpty()) return null

        val keywords = ArrayList<String>().apply {
            add(query)
            APP_ALIASES[query]?.let { addAll(it) }
            rest.firstOrNull()?.let { first -> APP_ALIASES[first]?.let { addAll(it) } }
        }
        val apps = installedApps(ctx)
        val hit = bestApp(apps, keywords, 1)
        if (hit == null) {
            // Con verbos flojos ("andá", "entrá") o frases largas dejamos que conteste la IA.
            if (loose || rest.size > 3) return null
            return "No encontré una aplicación instalada llamada «$query»."
        }
        return if (launch(ctx, hit.first)) "Abriendo ${hit.first.label}. 💜"
        else "No pude abrir ${hit.first.label}."
    }
}
