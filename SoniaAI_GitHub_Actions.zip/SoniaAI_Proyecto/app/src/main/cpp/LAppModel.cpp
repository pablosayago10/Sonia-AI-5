﻿/**
 * Copyright(c) Live2D Inc. All rights reserved.
 *
 * Use of this source code is governed by the Live2D Open Software license
 * that can be found at https://www.live2d.com/eula/live2d-open-software-license-agreement_en.html.
 */

#include "LAppModel.hpp"
#include <fstream>
#include <math.h>
#include <vector>
#include <CubismModelSettingJson.hpp>
#include <Motion/CubismMotion.hpp>
#include <Physics/CubismPhysics.hpp>
#include <CubismDefaultParameterId.hpp>
#include <Rendering/OpenGL/CubismRenderer_OpenGLES2.hpp>
#include <Utils/CubismString.hpp>
#include <Id/CubismIdManager.hpp>
#include <Motion/CubismMotionQueueEntry.hpp>
#include "LAppDefine.hpp"
#include "LAppPal.hpp"
#include "LAppTextureManager.hpp"
#include "LAppDelegate.hpp"
#include "Motion/CubismBreathUpdater.hpp"
#include "Motion/CubismLookUpdater.hpp"
#include "Motion/CubismExpressionUpdater.hpp"
#include "Motion/CubismEyeBlinkUpdater.hpp"
#include "Motion/CubismPhysicsUpdater.hpp"
#include "Motion/CubismPoseUpdater.hpp"

using namespace Live2D::Cubism::Framework;
using namespace Live2D::Cubism::Framework::DefaultParameterId;
using namespace LAppDefine;

LAppModel::LAppModel()
    : LAppModel_Common()
    , _modelSetting(NULL)
    , _userTimeSeconds(0.0f)
    , _motionUpdated(false)
    , _stateTime(0.0f)
    , _mouthOpen(0.0f)
    , _thinkBlend(0.0f)
{
    if (DebugLogEnable)
    {
        _debugMode = true;
    }

    _idParamAngleX = CubismFramework::GetIdManager()->GetId(ParamAngleX);
    _idParamAngleY = CubismFramework::GetIdManager()->GetId(ParamAngleY);
    _idParamAngleZ = CubismFramework::GetIdManager()->GetId(ParamAngleZ);
    _idParamBodyAngleX = CubismFramework::GetIdManager()->GetId(ParamBodyAngleX);
    _idParamEyeBallX = CubismFramework::GetIdManager()->GetId(ParamEyeBallX);
    _idParamEyeBallY = CubismFramework::GetIdManager()->GetId(ParamEyeBallY);
    _idParamMouthOpenY = CubismFramework::GetIdManager()->GetId(ParamMouthOpenY);

    _idMouthForm = CubismFramework::GetIdManager()->GetId("ParamMouthForm");
    _idEyeLSmile = CubismFramework::GetIdManager()->GetId("ParamEyeLSmile");
    _idEyeRSmile = CubismFramework::GetIdManager()->GetId("ParamEyeRSmile");
    _idEyeLOpen = CubismFramework::GetIdManager()->GetId("ParamEyeLOpen");
    _idEyeROpen = CubismFramework::GetIdManager()->GetId("ParamEyeROpen");
    _idBodyAngleY = CubismFramework::GetIdManager()->GetId("ParamBodyAngleY");
    _idBodyAngleZ = CubismFramework::GetIdManager()->GetId("ParamBodyAngleZ");
    static const char* const kFxNames[7] = {
        "Param41", "Param43", "Param46", "Param47", "Param", "Param2", "Param57"
    };
    for (int i = 0; i < 7; i++)
    {
        _idFx[i] = CubismFramework::GetIdManager()->GetId(kFxNames[i]);
        _fxBlend[i] = 0.0f;
    }
    for (int i = 0; i < EmoCount; i++) _emoCur[i] = 0.0f;
    _eyeCap = 1.0f;
    _eyeCapFrame = 1.0f;
    _emoTime = 0.0f;
    _actTime = 0.0f;
    _emoLast = 0;
    _actLast = 0;
}

LAppModel::~LAppModel()
{
    _renderBuffer.DestroyRenderTarget();

    ReleaseMotions();
    ReleaseExpressions();

    if (_modelSetting != NULL)
    {
        for (csmInt32 i = 0; i < _modelSetting->GetMotionGroupCount(); i++)
        {
            const csmChar* group = _modelSetting->GetMotionGroupName(i);
            ReleaseMotionGroup(group);
        }
        delete _modelSetting;
    }
}

void LAppModel::LoadAssets(const csmChar* dir, const csmChar* fileName)
{
    _modelHomeDir = dir;

    if (_debugMode)
    {
        LAppPal::PrintLogLn("[APP]load model setting: %s", fileName);
    }

    csmSizeInt size;
    const csmString path = csmString(dir) + fileName;

    csmByte* buffer = CreateBuffer(path.GetRawString(), &size);
    if (buffer == NULL)
    {
        LAppPal::PrintLogLn("[APP]no se pudo leer %s", path.GetRawString());
        return;
    }
    ICubismModelSetting* setting = new CubismModelSettingJson(buffer, size);
    DeleteBuffer(buffer, path.GetRawString());

    SetupModel(setting);

    if (_model == NULL)
    {
        LAppPal::PrintLogLn("Failed to LoadAssets().");
        return;
    }

    CreateRenderer(LAppDelegate::GetInstance()->GetWindowWidth(), LAppDelegate::GetInstance()->GetWindowHeight());

    SetupTextures();
}


void LAppModel::SetupModel(ICubismModelSetting* setting)
{
    _updating = true;
    _initialized = false;

    _modelSetting = setting;

    csmByte* buffer;
    csmSizeInt size;

    //Cubism Model
    if (strcmp(_modelSetting->GetModelFileName(), "") != 0)
    {
        csmString path = _modelSetting->GetModelFileName();
        path = _modelHomeDir + path;

        if (_debugMode)
        {
            LAppPal::PrintLogLn("[APP]create model: %s", setting->GetModelFileName());
        }

        buffer = CreateBuffer(path.GetRawString(), &size);
        if (buffer == NULL)
        {
            LAppPal::PrintLogLn("[APP]no se pudo leer el moc3: %s", path.GetRawString());
            return;
        }
        LoadModel(buffer, size);
        DeleteBuffer(buffer, path.GetRawString());
    }

    //Expression
    if (_modelSetting->GetExpressionCount() > 0)
    {
        const csmInt32 count = _modelSetting->GetExpressionCount();
        for (csmInt32 i = 0; i < count; i++)
        {
            csmString name = _modelSetting->GetExpressionName(i);
            csmString path = _modelSetting->GetExpressionFileName(i);
            path = _modelHomeDir + path;

            buffer = CreateBuffer(path.GetRawString(), &size);
            ACubismMotion* motion = LoadExpression(buffer, size, name.GetRawString());

            if (motion)
            {
                if (_expressions[name] != NULL)
                {
                    ACubismMotion::Delete(_expressions[name]);
                    _expressions[name] = NULL;
                }
                _expressions[name] = motion;
            }

            DeleteBuffer(buffer, path.GetRawString());
        }

        CubismExpressionUpdater* expression = CSM_NEW CubismExpressionUpdater(*_expressionManager);
        _updateScheduler.AddUpdatableList(expression);
    }

    //Physics
    if (strcmp(_modelSetting->GetPhysicsFileName(), "") != 0)
    {
        csmString path = _modelSetting->GetPhysicsFileName();
        path = _modelHomeDir + path;

        buffer = CreateBuffer(path.GetRawString(), &size);
        LoadPhysics(buffer, size);
        if (_physics != nullptr)
        {
            CubismPhysicsUpdater* physics = CSM_NEW CubismPhysicsUpdater(*_physics);
            _updateScheduler.AddUpdatableList(physics);
        }
        DeleteBuffer(buffer, path.GetRawString());
    }

    //Pose
    if (strcmp(_modelSetting->GetPoseFileName(), "") != 0)
    {
        csmString path = _modelSetting->GetPoseFileName();
        path = _modelHomeDir + path;

        buffer = CreateBuffer(path.GetRawString(), &size);
        LoadPose(buffer, size);
        if (_pose != nullptr)
        {
            CubismPoseUpdater* pose = CSM_NEW CubismPoseUpdater(*_pose);
            _updateScheduler.AddUpdatableList(pose);
        }
        DeleteBuffer(buffer, path.GetRawString());
    }

    //EyeBlink
    {
        if (_modelSetting->GetEyeBlinkParameterCount() > 0)
        {
            _eyeBlink = CubismEyeBlink::Create(_modelSetting);

            CubismEyeBlinkUpdater* eyeBlink = CSM_NEW CubismEyeBlinkUpdater(_motionUpdated, *_eyeBlink);
            _updateScheduler.AddUpdatableList(eyeBlink);
        }
    }

    //Breath
    {
        _breath = CubismBreath::Create();

        csmVector<CubismBreath::BreathParameterData> breathParameters;

        breathParameters.PushBack(CubismBreath::BreathParameterData(_idParamAngleX, 0.0f, 15.0f, 6.5345f, 0.5f));
        breathParameters.PushBack(CubismBreath::BreathParameterData(_idParamAngleY, 0.0f, 8.0f, 3.5345f, 0.5f));
        breathParameters.PushBack(CubismBreath::BreathParameterData(_idParamAngleZ, 0.0f, 10.0f, 5.5345f, 0.5f));
        breathParameters.PushBack(CubismBreath::BreathParameterData(_idParamBodyAngleX, 0.0f, 4.0f, 15.5345f, 0.5f));
        breathParameters.PushBack(CubismBreath::BreathParameterData(CubismFramework::GetIdManager()->GetId(ParamBreath), 0.5f, 0.5f, 3.2345f, 0.5f));

        _breath->SetParameters(breathParameters);

        CubismBreathUpdater* breath = CSM_NEW CubismBreathUpdater(*_breath);
        _updateScheduler.AddUpdatableList(breath);
    }

    //UserData
    if (strcmp(_modelSetting->GetUserDataFile(), "") != 0)
    {
        csmString path = _modelSetting->GetUserDataFile();
        path = _modelHomeDir + path;
        buffer = CreateBuffer(path.GetRawString(), &size);
        LoadUserData(buffer, size);
        DeleteBuffer(buffer, path.GetRawString());
    }

    // EyeBlinkIds
    {
        csmInt32 eyeBlinkIdCount = _modelSetting->GetEyeBlinkParameterCount();
        for (csmInt32 i = 0; i < eyeBlinkIdCount; ++i)
        {
            _eyeBlinkIds.PushBack(_modelSetting->GetEyeBlinkParameterId(i));
        }
    }

    // LipSyncIds
    {
        csmInt32 lipSyncIdCount = _modelSetting->GetLipSyncParameterCount();
        for (csmInt32 i = 0; i < lipSyncIdCount; ++i)
        {
            _lipSyncIds.PushBack(_modelSetting->GetLipSyncParameterId(i));
        }
    }

    // Look
    {
        _look = CubismLook::Create();

        csmVector<CubismLook::LookParameterData> lookParameters;

        lookParameters.PushBack(CubismLook::LookParameterData(_idParamAngleX, 30.0f));
        lookParameters.PushBack(CubismLook::LookParameterData(_idParamAngleY, 0.0f, 30.0f));
        lookParameters.PushBack(CubismLook::LookParameterData(_idParamAngleZ, 0.0f, 0.0f, -30.0f));
        lookParameters.PushBack(CubismLook::LookParameterData(_idParamBodyAngleX, 10.0f));
        lookParameters.PushBack(CubismLook::LookParameterData(_idParamEyeBallX, 1.0f));
        lookParameters.PushBack(CubismLook::LookParameterData(_idParamEyeBallY, 0.0f, 1.0f));

        _look->SetParameters(lookParameters);

        CubismLookUpdater* look = CSM_NEW CubismLookUpdater(*_look, *_dragManager);
        _updateScheduler.AddUpdatableList(look);
    }

    _updateScheduler.SortUpdatableList();

    if (_modelSetting == NULL || _modelMatrix == NULL)
    {
        LAppPal::PrintLogLn("Failed to SetupModel().");
        return;
    }

    //Layout
    csmMap<csmString, csmFloat32> layout;
    _modelSetting->GetLayoutMap(layout);
    _modelMatrix->SetupFromLayout(layout);

    _model->SaveParameters();

    for (csmInt32 i = 0; i < _modelSetting->GetMotionGroupCount(); i++)
    {
        const csmChar* group = _modelSetting->GetMotionGroupName(i);
        PreloadMotionGroup(group);
    }

    _motionManager->StopAllMotions();

    _updating = false;
    _initialized = true;
}

void LAppModel::PreloadMotionGroup(const csmChar* group)
{
    const csmInt32 count = _modelSetting->GetMotionCount(group);

    for (csmInt32 i = 0; i < count; i++)
    {
        //ex) idle_0
        csmString name = Utils::CubismString::GetFormatedString("%s_%d", group, i);
        csmString path = _modelSetting->GetMotionFileName(group, i);
        path = _modelHomeDir + path;

        if (_debugMode)
        {
            LAppPal::PrintLogLn("[APP]load motion: %s => [%s_%d] ", path.GetRawString(), group, i);
        }

        csmByte* buffer;
        csmSizeInt size;
        buffer = CreateBuffer(path.GetRawString(), &size);
        CubismMotion* tmpMotion = static_cast<CubismMotion*>(LoadMotion(buffer, size, name.GetRawString(), NULL, NULL, _modelSetting, group, i));

        if (tmpMotion)
        {
            tmpMotion->SetEffectIds(_eyeBlinkIds, _lipSyncIds);

            if (_motions[name] != NULL)
            {
                ACubismMotion::Delete(_motions[name]);
            }
            _motions[name] = tmpMotion;
        }

        DeleteBuffer(buffer, path.GetRawString());
    }
}

void LAppModel::ReleaseMotionGroup(const csmChar* group) const
{
    const csmInt32 count = _modelSetting->GetMotionCount(group);
    for (csmInt32 i = 0; i < count; i++)
    {
        csmString voice = _modelSetting->GetMotionSoundFileName(group, i);
        if (strcmp(voice.GetRawString(), "") != 0)
        {
            csmString path = voice;
            path = _modelHomeDir + path;
        }
    }
}

/**
* @brief すべてのモーションデータの解放
*
* すべてのモーションデータを解放する。
*/
void LAppModel::ReleaseMotions()
{
    for (csmMap<csmString, ACubismMotion*>::const_iterator iter = _motions.Begin(); iter != _motions.End(); ++iter)
    {
        ACubismMotion::Delete(iter->Second);
    }

    _motions.Clear();
}

/**
* @brief すべての表情データの解放
*
* すべての表情データを解放する。
*/
void LAppModel::ReleaseExpressions()
{
    for (csmMap<csmString, ACubismMotion*>::const_iterator iter = _expressions.Begin(); iter != _expressions.End(); ++iter)
    {
        ACubismMotion::Delete(iter->Second);
    }

    _expressions.Clear();
}

// Gestos del avatar segun el estado que manda la app (0 neutral, 1 pensando, 2 hablando).
// Solo usa parametros estandar del modelo: boca, inclinacion de cabeza y mirada.
void LAppModel::ApplyAvatarState(csmFloat32 dt)
{
    const int state = LAppDelegate::GetAvatarState();
    _stateTime += dt;

    const csmFloat32 k = dt * 8.0f > 1.0f ? 1.0f : dt * 8.0f; // suavizado

    csmFloat32 mouthTarget = 0.0f;
    if (state == 2)
    {
        // Boca que "habla": apertura irregular tipo silabas.
        csmFloat32 v = 0.5f + 0.35f * sinf(_stateTime * 14.0f) * (0.6f + 0.4f * sinf(_stateTime * 5.3f));
        mouthTarget = v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v);
    }
    _mouthOpen += (mouthTarget - _mouthOpen) * k;

    const csmFloat32 thinkTarget = (state == 1) ? 1.0f : 0.0f;
    _thinkBlend += (thinkTarget - _thinkBlend) * k;

    if (_mouthOpen > 0.001f)
    {
        _model->AddParameterValue(_idParamMouthOpenY, _mouthOpen);
    }
    if (_thinkBlend > 0.001f)
    {
        // Cabeza ladeada y mirada hacia arriba, con un leve balanceo.
        _model->AddParameterValue(_idParamAngleZ, (8.0f + 2.0f * sinf(_stateTime * 2.0f)) * _thinkBlend);
        _model->AddParameterValue(_idParamEyeBallY, 0.6f * _thinkBlend);
        _model->AddParameterValue(_idParamEyeBallX, 0.3f * _thinkBlend);
        _model->AddParameterValue(_idParamAngleY, 5.0f * _thinkBlend);
        _model->AddParameterValue(_idParamAngleX, 4.0f * sinf(_stateTime * 1.5f) * _thinkBlend);
    }
}

// Emociones. IMPORTANTE: este modelo solo usa (con efecto visible) estos parametros:
// boca (forma y apertura), ojos (apertura y sonrisa), cabeza (X/Y/Z) y cuerpo (X/Y/Z).
// Cejas, mejillas y pupilas del modelo NO estan conectadas, por eso no se usan.
// Orden: mouthForm, smileL, smileR, eyeCap, angX, angY, angZ, bodX, bodY, bodZ, mouthOpen
static const csmFloat32 kEmo[12][11] = {
    {  0.0f, 0.0f,  0.0f,  1.00f,  0.0f,   0.0f,  0.0f,  0.0f,  0.0f,  0.0f, 0.0f },  // 0 neutral
    {  1.0f, 0.85f, 0.85f, 1.00f,  0.0f,   4.0f,  4.0f,  0.0f,  2.0f,  0.0f, 0.0f },  // 1 feliz
    { -1.0f, 0.0f,  0.0f,  0.62f,  0.0f,  -9.0f,  0.0f,  0.0f,  3.0f,  0.0f, 0.0f },  // 2 enojada
    { -1.0f, 0.0f,  0.0f,  0.60f,  0.0f, -14.0f, -7.0f,  0.0f, -6.0f, -2.0f, 0.0f },  // 3 triste
    {  0.0f, 0.0f,  0.0f,  1.00f,  0.0f,   8.0f,  0.0f,  0.0f, -4.0f,  0.0f, 0.65f }, // 4 sorprendida
    { -0.2f, 0.0f,  0.0f,  0.85f,  7.0f,   3.0f,  8.0f,  2.0f,  0.0f,  2.0f, 0.0f },  // 5 pensativa
    {  0.35f,0.45f, 0.45f, 0.90f, -6.0f, -10.0f, -7.0f, -3.0f, -3.0f, -3.0f, 0.0f },  // 6 timida
    {  0.9f, 0.0f,  1.0f,  1.00f,  0.0f,   2.0f,  6.0f,  0.0f,  0.0f,  2.0f, 0.0f },  // 7 guino
    {  0.0f, 0.0f,  0.0f,  0.18f,  0.0f, -12.0f,  3.0f,  0.0f, -5.0f,  0.0f, 0.0f },  // 8 cansada
    {  1.0f, 1.0f,  1.0f,  1.00f,  0.0f,   6.0f,  3.0f,  0.0f,  0.0f,  0.0f, 0.3f },  // 9 risa
    {  0.7f, 0.0f,  0.0f,  0.70f,  3.0f,   8.0f,  6.0f,  0.0f,  2.0f,  2.0f, 0.0f },  // 10 presumida
    { -0.3f, 0.0f,  0.0f,  0.55f, -4.0f,  -3.0f,  7.0f,  2.0f, -2.0f,  3.0f, 0.0f }   // 11 aburrida
};

static csmFloat32 Env(csmFloat32 t, csmFloat32 dur)
{
    csmFloat32 x = t / dur;
    if (x < 0.0f) x = 0.0f;
    if (x > 1.0f) x = 1.0f;
    return sinf(3.14159265f * x);
}

static csmFloat32 Ramp(csmFloat32 t)
{
    csmFloat32 w = t * 1.5f;
    return w > 1.0f ? 1.0f : w;
}

// Mezcla suave hacia la emocion pedida + movimientos de cuerpo segun la actividad.
// Todo se SUMA a lo que ya hace el modelo (el motor recorta si algo se pasa del rango).
void LAppModel::ApplyEmotion(csmFloat32 dt)
{
    int e = LAppDelegate::GetAvatarEmotion();
    if (e < 0 || e > 11) e = 0;
    int act = LAppDelegate::GetAvatarActivity();
    if (act < 0 || act > 9) act = 0;
    if (e != _emoLast) { _emoLast = e; _emoTime = 0.0f; }
    if (act != _actLast) { _actLast = act; _actTime = 0.0f; }
    _emoTime += dt;
    _actTime += dt;

    const csmFloat32 k = dt * 5.0f > 1.0f ? 1.0f : dt * 5.0f;
    // indices: 0 mouthForm 1 smileL 2 smileR 3 eyeCap 4 angX 5 angY 6 angZ 7 bodX 8 bodY 9 bodZ 10 mouthOpen
    for (int i = 0; i < EmoCount; i++)
    {
        _emoCur[i] += (kEmo[e][i] - _emoCur[i]) * k;
    }
    _eyeCap = _emoCur[3];

    csmFloat32 add[EmoCount];
    for (int i = 0; i < EmoCount; i++) add[i] = _emoCur[i];
    add[3] = 0.0f;
    csmFloat32 cap = _eyeCap;

    // Movimiento propio de cada emocion.
    const csmFloat32 t = _emoTime;
    const csmFloat32 r = Ramp(t);
    switch (e)
    {
    case 1: add[9] += 2.5f * sinf(2.2f * t) * r; add[6] += 2.0f * sinf(2.2f * t + 1.0f) * r; break;
    case 2: add[4] += 1.2f * sinf(28.0f * t) * r; break;
    case 3: add[8] += 1.5f * sinf(0.9f * t) * r; add[5] += 1.5f * sinf(0.9f * t) * r; break;
    case 5: add[6] += 2.0f * sinf(1.1f * t) * r; add[4] += 3.0f * sinf(0.7f * t) * r; break;
    case 6: add[6] += 1.5f * sinf(2.0f * t) * r; break;
    case 8: add[5] += 3.0f * sinf(0.7f * t) * r; add[8] += 1.5f * sinf(0.7f * t) * r; break;
    case 9:
        add[8] += 3.0f * fabsf(sinf(9.0f * t)) * r; add[5] += 3.0f * sinf(9.0f * t) * r;
        add[10] += 0.3f * sinf(13.0f * t) * r; break;
    case 10: add[6] += 1.5f * sinf(1.5f * t) * r; break;
    case 11: add[4] += 5.0f * sinf(0.5f * t) * r; break;
    default: break;
    }

    // Actividades (mirar alrededor, bostezar, bailar, escuchar, dormir...).
    const csmFloat32 a = _actTime;
    const csmFloat32 w = Ramp(a);
    switch (act)
    {
    case 1: { csmFloat32 v = Env(a, 6.0f);
        add[4] += 22.0f * sinf(1.3f * a) * v; add[5] += 4.0f * sinf(0.9f * a) * v; add[7] += 4.0f * sinf(1.3f * a) * v; break; }
    case 2: { csmFloat32 v = Env(a, 4.0f);
        add[5] += 14.0f * v; add[8] += 9.0f * v; add[9] += 3.0f * sinf(2.0f * a) * v;
        add[1] += v; add[2] += v; add[0] += 0.6f * v; break; }
    case 3: { csmFloat32 v = Env(a, 3.5f);
        add[10] += powf(v, 0.7f); cap = cap < 1.0f - 0.75f * v ? cap : 1.0f - 0.75f * v;
        add[5] += 8.0f * v; add[8] += 3.0f * v; break; }
    case 4:
        add[9] += 8.0f * sinf(3.2f * a) * w; add[6] += 9.0f * sinf(3.2f * a + 0.6f) * w;
        add[8] += 3.0f * fabsf(sinf(3.2f * a)) * w; add[7] += 4.0f * sinf(1.6f * a) * w;
        add[5] += 3.0f * sinf(6.4f * a) * w; add[1] += 0.4f * w; add[2] += 0.4f * w; add[0] += 0.6f * w; break;
    case 5:
        add[6] += 9.0f * w; add[4] += 2.0f * sinf(1.3f * a) * w; add[5] += 3.0f * w; add[0] += 0.15f * w; break;
    case 6: { csmFloat32 c = 1.0f - 0.85f * w; cap = cap < c ? cap : c;
        add[5] += (-12.0f + 3.0f * sinf(0.7f * a)) * w; add[8] += (-5.0f + 1.5f * sinf(0.7f * a)) * w;
        add[6] += 3.0f * w; break; }
    case 7: { csmFloat32 c = 1.0f - 0.12f * w; cap = cap < c ? cap : c;
        add[5] += -7.0f * w; add[4] += 7.0f * sinf(1.8f * a) * w; add[7] += 1.5f * sinf(1.8f * a) * w;
        add[6] += 2.0f * sinf(0.9f * a) * w; break; }
    case 8: { csmFloat32 v = Env(a, 1.6f); add[5] += 9.0f * sinf(8.0f * a) * v; add[8] += 2.0f * sinf(8.0f * a) * v; break; }
    case 9: { csmFloat32 v = Env(a, 1.6f); add[4] += 16.0f * sinf(10.0f * a) * v; add[6] += 3.0f * sinf(10.0f * a) * v; break; }
    default: break;
    }
    _eyeCapFrame = cap < 0.0f ? 0.0f : (cap > 1.0f ? 1.0f : cap);

    if (add[0] != 0.0f) _model->AddParameterValue(_idMouthForm, add[0]);
    if (add[1] != 0.0f) _model->AddParameterValue(_idEyeLSmile, add[1]);
    if (add[2] != 0.0f) _model->AddParameterValue(_idEyeRSmile, add[2]);
    if (add[4] != 0.0f) _model->AddParameterValue(_idParamAngleX, add[4]);
    if (add[5] != 0.0f) _model->AddParameterValue(_idParamAngleY, add[5]);
    if (add[6] != 0.0f) _model->AddParameterValue(_idParamAngleZ, add[6]);
    if (add[7] != 0.0f) _model->AddParameterValue(_idParamBodyAngleX, add[7]);
    if (add[8] != 0.0f) _model->AddParameterValue(_idBodyAngleY, add[8]);
    if (add[9] != 0.0f) _model->AddParameterValue(_idBodyAngleZ, add[9]);
    if (add[10] > 0.0f) _model->AddParameterValue(_idParamMouthOpenY, add[10]);

    // Efectos extra del modelo (interruptores de prueba).
    for (int i = 0; i < 7; i++)
    {
        const csmFloat32 target = LAppDelegate::GetEffect(i) ? 1.0f : 0.0f;
        _fxBlend[i] += (target - _fxBlend[i]) * k;
        if (_fxBlend[i] > 0.001f) _model->AddParameterValue(_idFx[i], 30.0f * _fxBlend[i]);
    }
}

// Limita la apertura de los ojos (parpadeo incluido) para caras de enojo, sueno, etc.
void LAppModel::ApplyEyeCap()
{
    if (_eyeCapFrame >= 0.999f) return;
    const CubismId* ids[2] = { _idEyeLOpen, _idEyeROpen };
    for (int i = 0; i < 2; i++)
    {
        const csmFloat32 v = _model->GetParameterValue(ids[i]);
        if (v > _eyeCapFrame) _model->SetParameterValue(ids[i], _eyeCapFrame);
    }
}

void LAppModel::Update()
{
    const csmFloat32 deltaTimeSeconds = LAppPal::GetDeltaTime();
    _userTimeSeconds += deltaTimeSeconds;

    // モーションによるパラメータ更新の有無
    _motionUpdated = false;

    //-----------------------------------------------------------------
    _model->LoadParameters(); // 前回セーブされた状態をロード
    if (_motionManager->IsFinished())
    {
        // モーションの再生がない場合、待機モーションの中からランダムで再生する
        StartRandomMotion(MotionGroupIdle, PriorityIdle);
    }
    else
    {
        _motionUpdated = _motionManager->UpdateMotion(_model, deltaTimeSeconds); // モーションを更新
    }
    _model->SaveParameters(); // 状態を保存
    //-----------------------------------------------------------------

    // 不透明度
    _opacity = _model->GetModelOpacity();

    ApplyAvatarState(deltaTimeSeconds);
    ApplyEmotion(deltaTimeSeconds);

    _updateScheduler.OnLateUpdate(_model, deltaTimeSeconds);
    ApplyEyeCap();

    _model->Update();

}

CubismMotionQueueEntryHandle LAppModel::StartMotion(const csmChar* group, csmInt32 no, csmInt32 priority, ACubismMotion::FinishedMotionCallback onFinishedMotionHandler, ACubismMotion::BeganMotionCallback onBeganMotionHandler)
{
    if (priority == PriorityForce)
    {
        _motionManager->SetReservePriority(priority);
    }
    else if (!_motionManager->ReserveMotion(priority))
    {
        if (_debugMode)
        {
            LAppPal::PrintLogLn("[APP]can't start motion.");
        }
        return InvalidMotionQueueEntryHandleValue;
    }

    const csmString fileName = _modelSetting->GetMotionFileName(group, no);

    //ex) idle_0
    csmString name = Utils::CubismString::GetFormatedString("%s_%d", group, no);
    CubismMotion* motion = static_cast<CubismMotion*>(_motions[name.GetRawString()]);
    csmBool autoDelete = false;

    if (motion == NULL)
    {
        csmString path = fileName;
        path = _modelHomeDir + path;

        csmByte* buffer;
        csmSizeInt size;
        buffer = CreateBuffer(path.GetRawString(), &size);
        motion = static_cast<CubismMotion*>(LoadMotion(buffer, size, NULL, onFinishedMotionHandler, onBeganMotionHandler, _modelSetting, group, no));

        if (motion)
        {
            motion->SetEffectIds(_eyeBlinkIds, _lipSyncIds);
            autoDelete = true; // 終了時にメモリから削除
        }

        DeleteBuffer(buffer, path.GetRawString());
    }
    else
    {
        motion->SetBeganMotionHandler(onBeganMotionHandler);
        motion->SetFinishedMotionHandler(onFinishedMotionHandler);
    }

    //voice
    csmString voice = _modelSetting->GetMotionSoundFileName(group, no);
    if (strcmp(voice.GetRawString(), "") != 0)
    {
        csmString path = voice;
        path = _modelHomeDir + path;
    }

    if (_debugMode)
    {
        LAppPal::PrintLogLn("[APP]start motion: [%s_%d]", group, no);
    }
    return  _motionManager->StartMotionPriority(motion, autoDelete, priority);
}

CubismMotionQueueEntryHandle LAppModel::StartRandomMotion(const csmChar* group, csmInt32 priority, ACubismMotion::FinishedMotionCallback onFinishedMotionHandler, ACubismMotion::BeganMotionCallback onBeganMotionHandler)
{
    if (_modelSetting->GetMotionCount(group) == 0)
    {
        return InvalidMotionQueueEntryHandleValue;
    }

    csmInt32 no = rand() % _modelSetting->GetMotionCount(group);

    return StartMotion(group, no, priority, onFinishedMotionHandler, onBeganMotionHandler);
}

void LAppModel::DoDraw()
{
    if (_model == NULL)
    {
        return;
    }

    GetRenderer<Rendering::CubismRenderer_OpenGLES2>()->DrawModel();
}

void LAppModel::Draw(CubismMatrix44& matrix)
{
    if (_model == NULL)
    {
        return;
    }

    matrix.MultiplyByMatrix(_modelMatrix);

    GetRenderer<Rendering::CubismRenderer_OpenGLES2>()->SetMvpMatrix(&matrix);

    DoDraw();
}

csmBool LAppModel::HitTest(const csmChar* hitAreaName, csmFloat32 x, csmFloat32 y)
{
    // 透明時は当たり判定なし。
    if (_opacity < 1)
    {
        return false;
    }
    const csmInt32 count = _modelSetting->GetHitAreasCount();
    for (csmInt32 i = 0; i < count; i++)
    {
        if (strcmp(_modelSetting->GetHitAreaName(i), hitAreaName) == 0)
        {
            const CubismIdHandle drawID = _modelSetting->GetHitAreaId(i);
            return IsHit(drawID, x, y);
        }
    }
    return false; // 存在しない場合はfalse
}

void LAppModel::SetExpression(const csmChar* expressionID)
{
    ACubismMotion* motion = _expressions[expressionID];
    if (_debugMode)
    {
        LAppPal::PrintLogLn("[APP]expression: [%s]", expressionID);
    }

    if (motion != NULL)
    {
        _expressionManager->StartMotion(motion, false);
    }
    else
    {
        if (_debugMode) LAppPal::PrintLogLn("[APP]expression[%s] is null ", expressionID);
    }
}

void LAppModel::SetRandomExpression()
{
    if (_expressions.GetSize() == 0)
    {
        return;
    }

    csmInt32 no = rand() % _expressions.GetSize();
    csmMap<csmString, ACubismMotion*>::const_iterator map_ite;
    csmInt32 i = 0;
    for (map_ite = _expressions.Begin(); map_ite != _expressions.End(); map_ite++)
    {
        if (i == no)
        {
            csmString name = (*map_ite).First;
            SetExpression(name.GetRawString());
            return;
        }
        i++;
    }
}

void LAppModel::ReloadRenderer()
{
    DeleteRenderer();

    CreateRenderer(LAppDelegate::GetInstance()->GetWindowWidth(), LAppDelegate::GetInstance()->GetWindowHeight());

    SetupTextures();
}

void LAppModel::SetupTextures()
{
    for (csmInt32 modelTextureNumber = 0; modelTextureNumber < _modelSetting->GetTextureCount(); modelTextureNumber++)
    {
        // テクスチャ名が空文字だった場合はロード・バインド処理をスキップ
        if (strcmp(_modelSetting->GetTextureFileName(modelTextureNumber), "") == 0)
        {
            continue;
        }

        //OpenGLのテクスチャユニットにテクスチャをロードする
        csmString texturePath = _modelSetting->GetTextureFileName(modelTextureNumber);
        texturePath = _modelHomeDir + texturePath;

        LAppTextureManager::TextureInfo* texture = LAppDelegate::GetInstance()->GetTextureManager()->CreateTextureFromPngFile(texturePath.GetRawString());
        if (texture == NULL)
        {
            LAppPal::PrintLogLn("[APP]no se pudo cargar la textura: %s", texturePath.GetRawString());
            continue;
        }
        const csmInt32 glTextueNumber = texture->id;

        //OpenGL
        GetRenderer<Rendering::CubismRenderer_OpenGLES2>()->BindTexture(modelTextureNumber, glTextueNumber);
    }

#ifdef PREMULTIPLIED_ALPHA_ENABLE
    GetRenderer<Rendering::CubismRenderer_OpenGLES2>()->IsPremultipliedAlpha(true);
#else
    GetRenderer<Rendering::CubismRenderer_OpenGLES2>()->IsPremultipliedAlpha(false);
#endif
}

void LAppModel::MotionEventFired(const csmString& eventValue)
{
    CubismLogInfo("%s is fired on LAppModel!!", eventValue.GetRawString());
}

Csm::Rendering::CubismRenderTarget_OpenGLES2& LAppModel::GetRenderBuffer()
{
    return _renderBuffer;
}
