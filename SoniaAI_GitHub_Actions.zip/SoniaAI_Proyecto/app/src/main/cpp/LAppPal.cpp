/**
 * Copyright(c) Live2D Inc. All rights reserved.
 *
 * Use of this source code is governed by the Live2D Open Software license
 * that can be found at https://www.live2d.com/eula/live2d-open-software-license-agreement_en.html.
 */

#include "LAppPal.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <time.h>
#include <iostream>
#include <fstream>
#include <GLES2/gl2.h>
#include <android/log.h>
#include <Model/CubismMoc.hpp>
#include "LAppDefine.hpp"
#include "JniBridgeC.hpp"

using std::endl;
using namespace Csm;
using namespace std;
using namespace LAppDefine;

double LAppPal::s_currentFrame = 0.0;
double LAppPal::s_lastFrame = 0.0;
double LAppPal::s_deltaTime = 0.0;

csmByte* LAppPal::LoadFileAsBytes(const string filePath, csmSizeInt* outSize)
{
    //filePath;//
    const char* path = filePath.c_str();

    // file buffer
    char* buf = JniBridgeC::LoadFileAsBytesFromJava(path, outSize);

    // El SDK pide los shaders por nombre suelto ("VertShaderSrc.vert"), pero en este
    // proyecto estan en assets/Shaders/StandardES/. Si no estan en la raiz, se buscan ahi.
    if (buf == NULL && filePath.find('/') == string::npos)
    {
        const size_t n = filePath.size();
        const bool isShader = (n > 5 && (filePath.compare(n - 5, 5, ".vert") == 0 ||
                                          filePath.compare(n - 5, 5, ".frag") == 0));
        if (isShader)
        {
            const string alt = string("Shaders/StandardES/") + filePath;
            buf = JniBridgeC::LoadFileAsBytesFromJava(alt.c_str(), outSize);
        }
    }

    return reinterpret_cast<csmByte*>(buf);
}

void LAppPal::ReleaseBytes(csmByte* byteData)
{
    delete[] byteData;
}

csmFloat32  LAppPal::GetDeltaTime()
{
    return static_cast<csmFloat32>(s_deltaTime);
}

void LAppPal::UpdateTime()
{
    s_currentFrame = GetSystemTime();
    s_deltaTime = s_currentFrame - s_lastFrame;
    s_lastFrame = s_currentFrame;
}

void LAppPal::PrintLogLn(const csmChar* format, ...)
{
    va_list args;
    va_start(args, format);
    __android_log_vprint(ANDROID_LOG_DEBUG, "NativePrint", format, args);    // 標準出力でレンダリング
    va_end(args);
}

void LAppPal::PrintMessageLn(const csmChar* message)
{
    PrintLogLn("%s", message);
}

double LAppPal::GetSystemTime()
{
    struct timespec res;
    clock_gettime(CLOCK_MONOTONIC, &res);
    return (res.tv_sec + res.tv_nsec * 1e-9);
}
