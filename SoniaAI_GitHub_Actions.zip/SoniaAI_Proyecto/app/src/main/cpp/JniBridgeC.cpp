/**
 * Copyright(c) Live2D Inc. All rights reserved.
 *
 * Use of this source code is governed by the Live2D Open Software license
 * that can be found at https://www.live2d.com/eula/live2d-open-software-license-agreement_en.html.
 */

#include "JniBridgeC.hpp"
#include <algorithm>
#include <jni.h>
#include "LAppDelegate.hpp"
#include "LAppPal.hpp"

using namespace Csm;

static JavaVM* g_JVM; // JavaVM is valid for all threads, so just save it globally
static jclass  g_JniBridgeJavaClass;
static jmethodID g_GetAssetsMethodId;
static jmethodID g_LoadFileMethodId;
static jmethodID g_MoveTaskToBackMethodId;

JNIEnv* GetEnv()
{
    JNIEnv* env = NULL;
    g_JVM->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6);
    return env;
}

// The VM calls JNI_OnLoad when the native library is loaded
jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved)
{
    g_JVM = vm;

    JNIEnv *env;
    if (vm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6) != JNI_OK)
    {
        return JNI_ERR;
    }

    jclass clazz = env->FindClass("com/sonia/ai/Live2DJniBridge");
    if (clazz == NULL)
    {
        return JNI_ERR;
    }
    g_JniBridgeJavaClass = reinterpret_cast<jclass>(env->NewGlobalRef(clazz));
    g_GetAssetsMethodId = env->GetStaticMethodID(g_JniBridgeJavaClass, "GetAssetList", "(Ljava/lang/String;)[Ljava/lang/String;");
    g_LoadFileMethodId = env->GetStaticMethodID(g_JniBridgeJavaClass, "LoadFile", "(Ljava/lang/String;)[B");
    g_MoveTaskToBackMethodId = env->GetStaticMethodID(g_JniBridgeJavaClass, "MoveTaskToBack", "()V");

    return JNI_VERSION_1_6;
}

void JNICALL JNI_OnUnload(JavaVM *vm, void *reserved)
{
    JNIEnv *env = GetEnv();
    if (env != NULL && g_JniBridgeJavaClass != NULL)
    {
        env->DeleteGlobalRef(g_JniBridgeJavaClass);
    }
}

Csm::csmVector<Csm::csmString>JniBridgeC::GetAssetList(const Csm::csmString& path)
{
    Csm::csmVector<Csm::csmString> list;
    JNIEnv *env = GetEnv();
    if (env == NULL) return list;

    jstring jpath = env->NewStringUTF(path.GetRawString());
    jobjectArray obj = reinterpret_cast<jobjectArray>(env->CallStaticObjectMethod(g_JniBridgeJavaClass, g_GetAssetsMethodId, jpath));
    env->DeleteLocalRef(jpath);
    if (env->ExceptionCheck())
    {
        env->ExceptionClear();
        return list;
    }
    if (obj == NULL) return list;

    unsigned int size = static_cast<unsigned int>(env->GetArrayLength(obj));
    for (unsigned int i = 0; i < size; i++)
    {
        jstring jstr = reinterpret_cast<jstring>(env->GetObjectArrayElement(obj, i));
        if (jstr == NULL) continue;
        const char* chars = env->GetStringUTFChars(jstr, nullptr);
        if (chars != NULL)
        {
            list.PushBack(Csm::csmString(chars));
            env->ReleaseStringUTFChars(jstr, chars);
        }
        env->DeleteLocalRef(jstr);
    }
    env->DeleteLocalRef(obj);
    return list;
}

char* JniBridgeC::LoadFileAsBytesFromJava(const char* filePath, unsigned int* outSize)
{
    JNIEnv *env = GetEnv();
    if (env == NULL) return NULL;

    // ファイルロード
    jstring jpath = env->NewStringUTF(filePath);
    jbyteArray obj = (jbyteArray)env->CallStaticObjectMethod(g_JniBridgeJavaClass, g_LoadFileMethodId, jpath);
    env->DeleteLocalRef(jpath);
    if (env->ExceptionCheck())
    {
        env->ExceptionClear();
        return NULL;
    }

    // ファイルが見つからなかったらnullが返ってくるためチェック
    if (!obj)
    {
        return NULL;
    }

    *outSize = static_cast<unsigned int>(env->GetArrayLength(obj));

    char* buffer = new char[*outSize];
    env->GetByteArrayRegion(obj, 0, *outSize, reinterpret_cast<jbyte *>(buffer));
    env->DeleteLocalRef(obj);

    return buffer;
}

void JniBridgeC::MoveTaskToBack()
{
    JNIEnv *env = GetEnv();
    if (env == NULL) return;

    // アプリ終了
    env->CallStaticVoidMethod(g_JniBridgeJavaClass, g_MoveTaskToBackMethodId);
}

extern "C"
{
    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeOnStart(JNIEnv *env, jclass type)
    {
        LAppDelegate::GetInstance()->OnStart();
    }

    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeOnPause(JNIEnv *env, jclass type)
    {
        LAppDelegate::GetInstance()->OnPause();
    }

    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeOnStop(JNIEnv *env, jclass type)
    {
        LAppDelegate::GetInstance()->OnStop();
    }

    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeOnDestroy(JNIEnv *env, jclass type)
    {
        LAppDelegate::GetInstance()->OnDestroy();
    }

    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeOnSurfaceCreated(JNIEnv *env, jclass type)
    {
        LAppDelegate::GetInstance()->OnSurfaceCreate();
    }

    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeOnSurfaceChanged(JNIEnv *env, jclass type, jint width, jint height)
    {
        LAppDelegate::GetInstance()->OnSurfaceChanged(width, height);
    }

    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeOnDrawFrame(JNIEnv *env, jclass type)
    {
        LAppDelegate::GetInstance()->Run();
    }

    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeOnTouchesBegan(JNIEnv *env, jclass type, jfloat pointX, jfloat pointY)
    {
        LAppDelegate::GetInstance()->OnTouchBegan(pointX, pointY);
    }

    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeOnTouchesEnded(JNIEnv *env, jclass type, jfloat pointX, jfloat pointY)
    {
        LAppDelegate::GetInstance()->OnTouchEnded(pointX, pointY);
    }

    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeOnTouchesMoved(JNIEnv *env, jclass type, jfloat pointX, jfloat pointY)
    {
        LAppDelegate::GetInstance()->OnTouchMoved(pointX, pointY);
    }

    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeSetState(JNIEnv *env, jclass type, jint state)
    {
        LAppDelegate::SetAvatarState(static_cast<int>(state));
    }

    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeSetEmotion(JNIEnv *env, jclass type, jint emotion)
    {
        LAppDelegate::SetAvatarEmotion(static_cast<int>(emotion));
    }

    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeSetActivity(JNIEnv *env, jclass type, jint activity)
    {
        LAppDelegate::SetAvatarActivity(static_cast<int>(activity));
    }

    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeSetEffect(JNIEnv *env, jclass type, jint index, jboolean on)
    {
        LAppDelegate::SetEffect(static_cast<int>(index), on == JNI_TRUE);
    }

    JNIEXPORT void JNICALL
    Java_com_sonia_ai_Live2DJniBridge_nativeSetClearColor(JNIEnv *env, jclass type, jfloat r, jfloat g, jfloat b, jfloat a)
    {
        LAppDelegate::SetClearColor(r, g, b, a);
    }
}
