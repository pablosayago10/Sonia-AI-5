import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    ndkVersion = "26.3.11579264"
    externalNativeBuild { cmake { path = file("CMakeLists.txt"); version = "3.22.1" } }
    namespace = "com.sonia.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sonia.ai"
        // La librería de IA (litertlm-android) pide Android 7.0 (API 24) como mínimo;
        // por eso subimos minSdk de 23 a 24.
        minSdk = 24
        targetSdk = 35
        versionCode = 8
        versionName = "0.12.6-live2d"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // Sin esto, Java compilaba a 1.8 y Kotlin a 21 al mismo tiempo: esa mezcla es
    // la que hacía crashear al compilador de Kotlin al abrir MainActivity.kt.
    // Fijamos los dos en la misma versión (17) para que no choquen.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

// Con Kotlin 2.4, la forma vieja de fijar esto (android { kotlinOptions { ... } }) ya no
// se acepta: hay que ponerlo acá afuera, en su propio bloque "kotlin".
kotlin {
    compilerOptions {
        jvmTarget = JvmTarget.fromTarget("17")
    }
}

dependencies {
    // Runtime de Google para correr modelos de IA en el propio teléfono (sin internet).
    // OJO: antes decía "latest.release" (la versión más nueva, siempre). Eso se
    // rompió solo cuando Google sacó una versión nueva (0.20.0) compilada con una
    // versión de Java tan reciente que la herramienta de tu teléfono que arma el
    // APK (D8) todavía no sabe leerla ("Unsupported class file major version 69").
    // Por eso ahora fijamos la versión EXACTA que ya probamos que funciona en tu
    // teléfono, para que una actualización de Google no te rompa la compilación de
    // sorpresa otra vez.
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.19.1")
}
